package com.example.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.MediaPlayer
import com.example.model.AmbientSoundType
import com.example.model.QuranCatalog
import com.example.model.QuranPlaybackStatus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin
import kotlin.math.tanh
import kotlin.random.Random

class AmbientAudioEngine {

    companion object {
        private const val SAMPLE_RATE = 22050
        private const val BUFFER_SAMPLES = 2048
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    private val activeVolumes = ConcurrentHashMap<AmbientSoundType, Float>()
    @Volatile
    private var masterMuted = false

    private var synthJob: Job? = null
    private var audioTrack: AudioTrack? = null

    // Quran streaming player
    private var quranMediaPlayer: MediaPlayer? = null
    private val _quranStatus = MutableStateFlow(QuranPlaybackStatus.IDLE)
    val quranStatus: StateFlow<QuranPlaybackStatus> = _quranStatus.asStateFlow()

    private var currentSurahNumber: Int = 55
    private var currentReciterId: String = "ar.alafasy"
    private var quranEnabled: Boolean = false
    private var quranVolume: Float = 0.75f
    private var usedFallbackUrl: Boolean = false

    // Chime trigger state (mixed directly into audio output if synth running, or standalone)
    @Volatile
    private var chimeSamplesRemaining = 0
    @Volatile
    private var chimeSampleCursor = 0

    fun setSoundState(
        type: AmbientSoundType,
        enabled: Boolean,
        volume: Float,
        surahNumber: Int = currentSurahNumber,
        reciterId: String = currentReciterId
    ) {
        val clampedVolume = volume.coerceIn(0f, 1f)
        if (type == AmbientSoundType.QURAN) {
            val selectionChanged = (surahNumber != currentSurahNumber || reciterId != currentReciterId)
            currentSurahNumber = surahNumber
            currentReciterId = reciterId
            quranVolume = clampedVolume
            val wasEnabled = quranEnabled
            quranEnabled = enabled
            updateQuranVolume()

            if (enabled && (!wasEnabled || selectionChanged || _quranStatus.value == QuranPlaybackStatus.ERROR)) {
                startQuranStream(surahNumber, reciterId, useFallback = false)
            } else if (!enabled && wasEnabled) {
                stopQuranStream()
            }
            return
        }

        if (enabled && clampedVolume > 0.001f) {
            activeVolumes[type] = clampedVolume
        } else {
            activeVolumes.remove(type)
        }
        syncSynthLoop()
    }

    fun setMasterMuted(muted: Boolean) {
        masterMuted = muted
        updateQuranVolume()
    }

    fun updateQuranSelection(surahNumber: Int, reciterId: String) {
        val changed = surahNumber != currentSurahNumber || reciterId != currentReciterId
        currentSurahNumber = surahNumber
        currentReciterId = reciterId
        if (quranEnabled && changed) {
            startQuranStream(surahNumber, reciterId, useFallback = false)
        }
    }

    fun stopAllProceduralSounds() {
        activeVolumes.clear()
        syncSynthLoop()
    }

    fun stopAll() {
        activeVolumes.clear()
        syncSynthLoop()
        quranEnabled = false
        stopQuranStream()
    }

    fun playGentleBell() {
        chimeSampleCursor = 0
        chimeSamplesRemaining = SAMPLE_RATE * 2
        if (synthJob == null || synthJob?.isActive != true) {
            scope.launch(Dispatchers.Default) {
                playStandaloneBell()
            }
        }
    }

    private fun playStandaloneBell() {
        val totalSamples = (SAMPLE_RATE * 1.8).toInt()
        val buffer = ShortArray(totalSamples)
        for (i in 0 until totalSamples) {
            val t = i.toDouble() / SAMPLE_RATE
            val env = exp(-t * 2.6)
            val s = (sin(2.0 * PI * 528.0 * t) * 0.55 +
                sin(2.0 * PI * 792.0 * t) * 0.25 +
                sin(2.0 * PI * 1056.0 * t) * 0.12) * env * 0.35
            buffer[i] = (s.coerceIn(-1.0, 1.0) * Short.MAX_VALUE).toInt().toShort()
        }
        val minBuf = AudioTrack.getMinBufferSize(
            SAMPLE_RATE,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        ).coerceAtLeast(totalSamples * 2)
        val track = createAudioTrack(minBuf) ?: return
        try {
            track.play()
            track.write(buffer, 0, totalSamples)
            Thread.sleep(1700)
        } catch (_: Throwable) {
        } finally {
            runCatching {
                track.stop()
                track.release()
            }
        }
    }

    private fun syncSynthLoop() {
        val hasAny = activeVolumes.isNotEmpty()
        if (hasAny && (synthJob == null || synthJob?.isActive != true)) {
            synthJob = scope.launch { runProceduralAudioLoop() }
        } else if (!hasAny) {
            synthJob?.cancel()
            synthJob = null
        }
    }

    private fun createAudioTrack(minBufferBytes: Int): AudioTrack? = try {
        AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(SAMPLE_RATE)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(minBufferBytes)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
    } catch (_: Throwable) {
        null
    }

    private fun runProceduralAudioLoop() {
        val minBuf = AudioTrack.getMinBufferSize(
            SAMPLE_RATE,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        ).coerceAtLeast(BUFFER_SAMPLES * 2)

        val track = createAudioTrack(minBuf * 2) ?: return
        audioTrack = track
        try {
            track.play()
        } catch (_: Throwable) {
            runCatching { track.release() }
            return
        }

        val buffer = ShortArray(BUFFER_SAMPLES)
        val rng = Random(System.currentTimeMillis())

        // Pink / brown filter states
        var b0 = 0.0; var b1 = 0.0; var b2 = 0.0
        var rainLp = 0.0
        var rainDropEnv = 0.0
        var rainDropPhase = 0.0
        var rainDropFreq = 1200.0

        // Fireplace states
        var fireBrown = 0.0
        var crackleEnv = 0.0
        var crackleFilter = 0.0
        var fireLfoPhase = 0.0

        // Ocean states
        var oceanLp = 0.0
        var oceanLfoPhase = 0.0

        // Brown noise state
        var brownState = 0.0

        // Forest wind & birds
        var windLp = 0.0
        var windLfo = 0.0
        var birdEnv = 0.0
        var birdPhase = 0.0
        var birdBaseFreq = 1800.0
        var birdTimer = SAMPLE_RATE * 2

        // Ney flute & warm drone
        var neyPhase1 = 0.0
        var neyPhase2 = 0.0
        var neyDronePhase = 0.0
        var neyNoteTimer = 0
        var neyCurrentFreq = 293.66 // D4
        var neyTargetFreq = 293.66
        var neyBreathLp = 0.0
        val neyScale = doubleArrayOf(293.66, 329.63, 349.23, 440.0, 466.16, 523.25, 440.0, 349.23)
        var neyScaleIdx = 0

        // Arabic Oud Karplus-Strong plucked string synthesizer (Maqam Hijaz & Nahawand)
        val oudMaxDelay = 512
        val oudDelayLine = DoubleArray(oudMaxDelay)
        val oudDroneLine = DoubleArray(oudMaxDelay)
        var oudIdx = 0
        var oudDroneIdx = 0
        var oudDelayLen = 150
        val oudDroneLen = (SAMPLE_RATE / 146.83).toInt().coerceIn(30, oudMaxDelay - 1) // D3 drone
        var oudNoteTimer = 0
        var oudDroneTimer = 0
        // Maqam Hijaz on D: D3, Eb3, F#3, G3, A3, Bb3, C4, D4
        val maqamHijaz = doubleArrayOf(
            146.83, 155.56, 185.00, 196.00, 220.00, 233.08, 261.63, 293.66,
            233.08, 220.00, 196.00, 185.00, 155.56, 146.83
        )
        val oudPattern = intArrayOf(0, 2, 3, 4, 3, 2, 1, 0, 4, 5, 7, 5, 4, 3, 2, 0)
        var oudStep = 0
        var oudPrevSample = 0.0
        var oudDronePrev = 0.0

        while (scope.isActive && activeVolumes.isNotEmpty()) {
            val rainVol = activeVolumes[AmbientSoundType.RAIN] ?: 0f
            val fireVol = activeVolumes[AmbientSoundType.FIREPLACE] ?: 0f
            val oudVol = activeVolumes[AmbientSoundType.OUD] ?: 0f
            val oceanVol = activeVolumes[AmbientSoundType.OCEAN] ?: 0f
            val forestVol = activeVolumes[AmbientSoundType.FOREST_BIRDS] ?: 0f
            val neyVol = activeVolumes[AmbientSoundType.NEY_DRONE] ?: 0f
            val brownVol = activeVolumes[AmbientSoundType.BROWN_NOISE] ?: 0f

            for (i in 0 until BUFFER_SAMPLES) {
                val white = rng.nextDouble() * 2.0 - 1.0
                // Shared pink noise approximation
                b0 = 0.99765 * b0 + white * 0.0990460
                b1 = 0.96300 * b1 + white * 0.2965164
                b2 = 0.57000 * b2 + white * 1.0526913
                val pink = (b0 + b1 + b2 + white * 0.1848) * 0.16

                var mix = 0.0

                // 1. Gentle Rain
                if (rainVol > 0f) {
                    rainLp = rainLp * 0.72 + pink * 0.28
                    if (rng.nextDouble() < 0.0018) {
                        rainDropEnv = 0.28 + rng.nextDouble() * 0.25
                        rainDropFreq = 900.0 + rng.nextDouble() * 1400.0
                    }
                    rainDropPhase += 2.0 * PI * rainDropFreq / SAMPLE_RATE
                    if (rainDropPhase > 2.0 * PI) rainDropPhase -= 2.0 * PI
                    val drop = sin(rainDropPhase) * rainDropEnv * 0.18
                    rainDropEnv *= 0.985
                    mix += (rainLp * 0.85 + drop) * rainVol
                }

                // 2. Crackling Firewood
                if (fireVol > 0f) {
                    fireLfoPhase += 2.0 * PI * 0.35 / SAMPLE_RATE
                    if (fireLfoPhase > 2.0 * PI) fireLfoPhase -= 2.0 * PI
                    fireBrown = (fireBrown + white * 0.035) * 0.992
                    val rumble = fireBrown * (2.6 + 0.5 * sin(fireLfoPhase))

                    if (rng.nextDouble() < 0.0022) {
                        crackleEnv = 0.45 + rng.nextDouble() * 0.55
                    }
                    val sharpPop = (white - crackleFilter) * crackleEnv
                    crackleFilter = crackleFilter * 0.55 + white * 0.45
                    crackleEnv *= 0.965

                    mix += (rumble * 0.75 + sharpPop * 0.42) * fireVol
                }

                // 3. Arabic Oud (Karplus-Strong on Maqam Hijaz)
                if (oudVol > 0f) {
                    if (oudNoteTimer <= 0) {
                        val freq = maqamHijaz[oudPattern[oudStep % oudPattern.size]]
                        oudDelayLen = (SAMPLE_RATE / freq).toInt().coerceIn(24, oudMaxDelay - 1)
                        // Pluck excitation burst
                        for (k in 0 until oudDelayLen) {
                            val shaped = (rng.nextDouble() * 2.0 - 1.0) * sin(PI * k / oudDelayLen)
                            oudDelayLine[k] = shaped * 0.75
                        }
                        oudIdx = 0
                        oudStep++
                        // Organic rubato timing between 0.45s and 1.15s
                        oudNoteTimer = (SAMPLE_RATE * (0.48 + (oudStep % 3) * 0.24)).toInt()
                    }
                    oudNoteTimer--

                    if (oudDroneTimer <= 0) {
                        for (k in 0 until oudDroneLen) {
                            oudDroneLine[k] = (rng.nextDouble() * 2.0 - 1.0) * 0.35
                        }
                        oudDroneIdx = 0
                        oudDroneTimer = SAMPLE_RATE * 3
                    }
                    oudDroneTimer--

                    val nextIdx = (oudIdx + 1) % oudDelayLen
                    val currentOut = oudDelayLine[oudIdx]
                    val filtered = 0.9945 * 0.5 * (currentOut + oudPrevSample)
                    oudPrevSample = currentOut
                    oudDelayLine[oudIdx] = filtered
                    oudIdx = nextIdx

                    val nextDroneIdx = (oudDroneIdx + 1) % oudDroneLen
                    val droneOut = oudDroneLine[oudDroneIdx]
                    val droneFiltered = 0.996 * 0.5 * (droneOut + oudDronePrev)
                    oudDronePrev = droneOut
                    oudDroneLine[oudDroneIdx] = droneFiltered
                    oudDroneIdx = nextDroneIdx

                    mix += (currentOut * 0.68 + droneOut * 0.28) * oudVol
                }

                // 4. Ocean Waves
                if (oceanVol > 0f) {
                    oceanLfoPhase += 2.0 * PI * 0.11 / SAMPLE_RATE
                    if (oceanLfoPhase > 2.0 * PI) oceanLfoPhase -= 2.0 * PI
                    val swell = 0.25 + 0.75 * (0.5 + 0.5 * sin(oceanLfoPhase))
                    val cutoff = 0.08 + 0.24 * swell
                    oceanLp = oceanLp * (1.0 - cutoff) + pink * cutoff
                    mix += oceanLp * (0.5 + 0.9 * swell) * oceanVol
                }

                // 5. Forest Breeze & Birds
                if (forestVol > 0f) {
                    windLfo += 2.0 * PI * 0.18 / SAMPLE_RATE
                    if (windLfo > 2.0 * PI) windLfo -= 2.0 * PI
                    val windEnv = 0.55 + 0.45 * sin(windLfo)
                    windLp = windLp * 0.92 + pink * 0.08
                    if (birdTimer <= 0) {
                        birdEnv = 0.22
                        birdBaseFreq = 1650.0 + rng.nextDouble() * 1100.0
                        birdTimer = SAMPLE_RATE * (2 + rng.nextInt(4))
                    }
                    birdTimer--
                    val chirpMod = sin(2.0 * PI * 14.0 * birdPhase / (2.0 * PI))
                    birdPhase += 2.0 * PI * (birdBaseFreq + 160.0 * chirpMod) / SAMPLE_RATE
                    if (birdPhase > 2.0 * PI) birdPhase -= 2.0 * PI
                    val bird = sin(birdPhase) * birdEnv * 0.35
                    birdEnv *= 0.9988
                    mix += (windLp * windEnv * 0.75 + bird) * forestVol
                }

                // 6. Meditative Ney Flute + Drone
                if (neyVol > 0f) {
                    if (neyNoteTimer <= 0) {
                        neyScaleIdx = (neyScaleIdx + 1) % neyScale.size
                        neyTargetFreq = neyScale[neyScaleIdx]
                        neyNoteTimer = SAMPLE_RATE * 3
                    }
                    neyNoteTimer--
                    neyCurrentFreq += (neyTargetFreq - neyCurrentFreq) * 0.0008
                    val vib = sin(neyDronePhase * 5.0) * 1.8
                    neyPhase1 += 2.0 * PI * (neyCurrentFreq + vib) / SAMPLE_RATE
                    neyPhase2 += 2.0 * PI * (neyCurrentFreq * 2.0) / SAMPLE_RATE
                    neyDronePhase += 2.0 * PI * 146.83 / SAMPLE_RATE
                    if (neyPhase1 > 2.0 * PI) neyPhase1 -= 2.0 * PI
                    if (neyPhase2 > 2.0 * PI) neyPhase2 -= 2.0 * PI
                    if (neyDronePhase > 2.0 * PI) neyDronePhase -= 2.0 * PI

                    neyBreathLp = neyBreathLp * 0.86 + white * 0.14
                    val flute = sin(neyPhase1) * 0.22 + sin(neyPhase2) * 0.05 + neyBreathLp * 0.06
                    val drone = sin(neyDronePhase) * 0.14 + sin(neyDronePhase * 1.5) * 0.07
                    mix += (flute + drone) * neyVol
                }

                // 7. Deep Focus Brown Noise
                if (brownVol > 0f) {
                    brownState = (brownState + white * 0.032) * 0.993
                    mix += brownState * 2.4 * brownVol
                }

                // Optional gentle milestone/completion chime overlay
                if (chimeSamplesRemaining > 0) {
                    val t = chimeSampleCursor.toDouble() / SAMPLE_RATE
                    val env = exp(-t * 2.5)
                    val chime = (sin(2.0 * PI * 528.0 * t) * 0.55 +
                        sin(2.0 * PI * 792.0 * t) * 0.22) * env * 0.35
                    mix += chime
                    chimeSampleCursor++
                    chimeSamplesRemaining--
                }

                val finalSample = if (masterMuted) 0.0 else tanh(mix * 0.85)
                buffer[i] = (finalSample.coerceIn(-1.0, 1.0) * Short.MAX_VALUE).toInt().toShort()
            }

            try {
                track.write(buffer, 0, BUFFER_SAMPLES)
            } catch (_: Throwable) {
                break
            }
        }

        runCatching {
            track.stop()
            track.release()
        }
        if (audioTrack === track) {
            audioTrack = null
        }
    }

    private fun startQuranStream(surahNumber: Int, reciterId: String, useFallback: Boolean) {
        stopQuranStream()
        usedFallbackUrl = useFallback
        _quranStatus.value = QuranPlaybackStatus.BUFFERING

        val url = if (!useFallback) {
            QuranCatalog.primaryUrl(reciterId, surahNumber)
        } else {
            QuranCatalog.fallbackUrl(surahNumber)
        }

        val player = MediaPlayer().apply {
            setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            isLooping = true
            setOnPreparedListener { mp ->
                if (quranEnabled) {
                    val v = if (masterMuted) 0f else quranVolume
                    mp.setVolume(v, v)
                    mp.start()
                    _quranStatus.value = QuranPlaybackStatus.PLAYING
                } else {
                    runCatching { mp.release() }
                    _quranStatus.value = QuranPlaybackStatus.IDLE
                }
            }
            setOnErrorListener { _, _, _ ->
                if (!usedFallbackUrl && quranEnabled) {
                    startQuranStream(surahNumber, reciterId, useFallback = true)
                } else {
                    _quranStatus.value = QuranPlaybackStatus.ERROR
                }
                true
            }
        }
        quranMediaPlayer = player
        try {
            player.setDataSource(url)
            player.prepareAsync()
        } catch (_: Throwable) {
            if (!usedFallbackUrl && quranEnabled) {
                startQuranStream(surahNumber, reciterId, useFallback = true)
            } else {
                _quranStatus.value = QuranPlaybackStatus.ERROR
            }
        }
    }

    private fun updateQuranVolume() {
        val v = if (masterMuted) 0f else quranVolume
        runCatching {
            quranMediaPlayer?.setVolume(v, v)
        }
    }

    private fun stopQuranStream() {
        runCatching {
            quranMediaPlayer?.stop()
        }
        runCatching {
            quranMediaPlayer?.release()
        }
        quranMediaPlayer = null
        _quranStatus.value = QuranPlaybackStatus.IDLE
    }

    fun release() {
        stopAll()
        scope.cancel()
    }
}
