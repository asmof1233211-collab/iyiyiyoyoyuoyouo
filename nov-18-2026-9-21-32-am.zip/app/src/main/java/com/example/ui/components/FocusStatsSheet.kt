package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.BarChart
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.Today
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.DailyFocusStat
import com.example.ui.theme.AmberGold
import com.example.ui.theme.GlassBorder
import com.example.ui.theme.JadeDeep
import com.example.ui.theme.JadeSurface
import com.example.ui.theme.JadeSurfaceElevated
import com.example.ui.theme.OutfitFontFamily
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlin.math.max

enum class StatsMetric(val arabicLabel: String, val unitArabic: String) {
    SESSIONS("الجلسات", "جلسة"),
    MINUTES("الدقائق", "دقيقة")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FocusStatsSheet(
    weeklyStats: List<DailyFocusStat>,
    todaySessions: Int,
    todayMinutes: Int,
    weekSessions: Int,
    weekMinutes: Int,
    totalLifetimeSessions: Int,
    accentColor: Color,
    secondaryColor: Color,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var selectedMetric by remember { mutableStateOf(StatsMetric.SESSIONS) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = JadeSurface,
        contentColor = TextPrimary
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .navigationBarsPadding()
                .padding(horizontal = 20.dp)
                .padding(bottom = 26.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(
                    imageVector = Icons.Rounded.BarChart,
                    contentDescription = null,
                    tint = accentColor
                )
                Column {
                    Text(
                        text = "إحصائيات التركيز",
                        style = MaterialTheme.typography.titleLarge,
                        color = TextPrimary
                    )
                    Text(
                        text = "مقارنة إنجاز اليوم بمجموع الأسبوع (الإجمالي: $totalLifetimeSessions جلسات)",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary
                    )
                }
            }

            // Today vs This Week comparison cards
            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                StatsSummaryCard(
                    title = "إنجاز اليوم",
                    sessionsCount = todaySessions,
                    minutesCount = todayMinutes,
                    icon = Icons.Rounded.Today,
                    highlightColor = accentColor,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("today_stats_card")
                )
                StatsSummaryCard(
                    title = "هذا الأسبوع",
                    sessionsCount = weekSessions,
                    minutesCount = weekMinutes,
                    icon = Icons.Rounded.CalendarMonth,
                    highlightColor = secondaryColor,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("week_stats_card")
                )
            }

            // Metric selector (Sessions vs Minutes)
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "التقدّم خلال ٧ أيام",
                    style = MaterialTheme.typography.titleMedium,
                    color = TextPrimary
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatsMetric.entries.forEach { metric ->
                        FilterChip(
                            selected = selectedMetric == metric,
                            onClick = { selectedMetric = metric },
                            label = { Text(metric.arabicLabel) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = accentColor.copy(alpha = 0.25f),
                                selectedLabelColor = accentColor
                            ),
                            modifier = Modifier.testTag("metric_chip_${metric.name}")
                        )
                    }
                }
            }

            FocusStatsChart(
                stats = weeklyStats,
                metric = selectedMetric,
                accentColor = accentColor,
                secondaryColor = secondaryColor
            )
        }
    }
}

@Composable
private fun StatsSummaryCard(
    title: String,
    sessionsCount: Int,
    minutesCount: Int,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    highlightColor: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(18.dp),
        color = JadeSurfaceElevated,
        border = BorderStroke(1.dp, highlightColor.copy(alpha = 0.45f)),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = highlightColor,
                    modifier = Modifier.size(18.dp)
                )
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelLarge,
                    color = TextSecondary
                )
            }
            Text(
                text = "$sessionsCount جلسات",
                style = MaterialTheme.typography.headlineSmall,
                color = highlightColor,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = formatFocusDurationArabic(minutesCount),
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondary
            )
        }
    }
}

@Composable
fun FocusStatsChart(
    stats: List<DailyFocusStat>,
    metric: StatsMetric,
    accentColor: Color,
    secondaryColor: Color,
    modifier: Modifier = Modifier
) {
    val safeStats = if (stats.isEmpty()) emptyList() else stats
    var selectedIndex by remember(safeStats) {
        mutableIntStateOf((safeStats.size - 1).coerceAtLeast(0))
    }

    val rawValues = safeStats.map {
        if (metric == StatsMetric.SESSIONS) it.sessions.toFloat() else it.minutes.toFloat()
    }
    val maxDataVal = rawValues.maxOrNull() ?: 0f
    val yAxisMax = when (metric) {
        StatsMetric.SESSIONS -> max(4f, ((maxDataVal.toInt() + 1) / 2 + 1) * 2f)
        StatsMetric.MINUTES -> max(60f, ((maxDataVal.toInt() / 30) + 1) * 30f)
    }

    val animProgress by animateFloatAsState(
        targetValue = 1f,
        animationSpec = tween(durationMillis = 650, easing = FastOutSlowInEasing),
        label = "chart_grow"
    )

    val textMeasurer = rememberTextMeasurer()
    val axisLabelStyle = TextStyle(
        fontFamily = OutfitFontFamily,
        fontSize = 11.sp,
        color = TextMuted
    )
    val dayLabelStyle = MaterialTheme.typography.labelSmall.copy(
        color = TextSecondary,
        fontSize = 10.sp
    )

    val selectedStat = safeStats.getOrNull(selectedIndex)

    Surface(
        shape = RoundedCornerShape(20.dp),
        color = JadeSurfaceElevated,
        border = BorderStroke(1.dp, GlassBorder),
        modifier = modifier
            .fillMaxWidth()
            .testTag("focus_stats_chart")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Interactive Tooltip header
            if (selectedStat != null) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = JadeDeep.copy(alpha = 0.72f),
                    border = BorderStroke(1.dp, accentColor.copy(alpha = 0.45f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                    ) {
                        Text(
                            text = "${selectedStat.dayLabelArabic} (${selectedStat.dateKey})",
                            style = MaterialTheme.typography.labelLarge,
                            color = if (selectedStat.isToday) accentColor else TextPrimary
                        )
                        Text(
                            text = "${selectedStat.sessions} جلسات • ${selectedStat.minutes} دقيقة",
                            style = MaterialTheme.typography.labelLarge,
                            color = AmberGold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            if (safeStats.all { it.sessions == 0 }) {
                Text(
                    text = "أكمل أول جلسة تركيز ليظهر منحنى تقدّمك اليومي والأسبوعي هنا.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary,
                    modifier = Modifier.padding(bottom = 10.dp)
                )
            }

            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(190.dp)
                    .pointerInput(safeStats) {
                        detectTapGestures { offset ->
                            if (safeStats.isNotEmpty()) {
                                val leftPad = 34.dp.toPx()
                                val chartW = (size.width - leftPad - 8.dp.toPx()).coerceAtLeast(1f)
                                val relX = (offset.x - leftPad).coerceIn(0f, chartW - 1f)
                                val slotW = chartW / safeStats.size
                                selectedIndex = (relX / slotW).toInt().coerceIn(0, safeStats.lastIndex)
                            }
                        }
                    }
            ) {
                val leftAxisWidth = 34.dp.toPx()
                val bottomLabelHeight = 24.dp.toPx()
                val topPad = 10.dp.toPx()
                val rightPad = 8.dp.toPx()

                val chartLeft = leftAxisWidth
                val chartWidth = (size.width - chartLeft - rightPad).coerceAtLeast(1f)
                val chartHeight = (size.height - topPad - bottomLabelHeight).coerceAtLeast(1f)
                val chartBottom = topPad + chartHeight

                // Cartesian Grid + Y-axis ticks (4 steps)
                val tickSteps = 4
                val dashEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 8f), 0f)
                for (step in 0..tickSteps) {
                    val frac = step / tickSteps.toFloat()
                    val y = chartBottom - frac * chartHeight
                    drawLine(
                        color = Color.White.copy(alpha = if (step == 0) 0.22f else 0.10f),
                        start = Offset(chartLeft, y),
                        end = Offset(chartLeft + chartWidth, y),
                        strokeWidth = 1.2f,
                        pathEffect = if (step == 0) null else dashEffect
                    )
                    val tickVal = (yAxisMax * frac).toInt()
                    val measured = textMeasurer.measure(tickVal.toString(), style = axisLabelStyle)
                    drawText(
                        textLayoutResult = measured,
                        topLeft = Offset(
                            x = (leftAxisWidth - measured.size.width - 6.dp.toPx()).coerceAtLeast(0f),
                            y = y - measured.size.height / 2f
                        )
                    )
                }

                if (safeStats.isNotEmpty()) {
                    val slotWidth = chartWidth / safeStats.size
                    val barWidth = (slotWidth * 0.48f).coerceAtMost(28.dp.toPx())
                    val pointOffsets = mutableListOf<Offset>()

                    safeStats.forEachIndexed { idx, stat ->
                        val v = if (metric == StatsMetric.SESSIONS) {
                            stat.sessions.toFloat()
                        } else {
                            stat.minutes.toFloat()
                        }
                        val barRatio = (v / yAxisMax).coerceIn(0f, 1f) * animProgress
                        val barH = (barRatio * chartHeight).coerceAtLeast(if (v > 0f) 4.dp.toPx() else 0f)
                        val centerX = chartLeft + slotWidth * idx + slotWidth / 2f
                        val barLeft = centerX - barWidth / 2f
                        val barTop = chartBottom - barH
                        val isSelected = idx == selectedIndex

                        // Selected slot highlight backdrop
                        if (isSelected) {
                            drawRoundRect(
                                color = accentColor.copy(alpha = 0.08f),
                                topLeft = Offset(chartLeft + slotWidth * idx + 2.dp.toPx(), topPad),
                                size = Size(slotWidth - 4.dp.toPx(), chartHeight),
                                cornerRadius = CornerRadius(10.dp.toPx(), 10.dp.toPx())
                            )
                        }

                        // Bar column
                        if (barH > 0f) {
                            val topColor = if (stat.isToday) accentColor else secondaryColor
                            val bottomColor = topColor.copy(alpha = 0.35f)
                            drawRoundRect(
                                brush = Brush.verticalGradient(
                                    colors = listOf(topColor, bottomColor),
                                    startY = barTop,
                                    endY = chartBottom
                                ),
                                topLeft = Offset(barLeft, barTop),
                                size = Size(barWidth, barH),
                                cornerRadius = CornerRadius(8.dp.toPx(), 8.dp.toPx())
                            )
                        } else {
                            // Subtle baseline dot when 0
                            drawCircle(
                                color = Color.White.copy(alpha = 0.16f),
                                radius = 2.5.dp.toPx(),
                                center = Offset(centerX, chartBottom - 3.dp.toPx())
                            )
                        }

                        pointOffsets.add(Offset(centerX, barTop))

                        // X-axis Arabic day label
                        val labelStyle = dayLabelStyle.copy(
                            color = when {
                                isSelected -> accentColor
                                stat.isToday -> AmberGold
                                else -> TextSecondary
                            },
                            fontWeight = if (stat.isToday || isSelected) FontWeight.Bold else FontWeight.Normal
                        )
                        val measuredDay = textMeasurer.measure(stat.dayLabelArabic, style = labelStyle)
                        drawText(
                            textLayoutResult = measuredDay,
                            topLeft = Offset(
                                x = centerX - measuredDay.size.width / 2f,
                                y = chartBottom + 6.dp.toPx()
                            )
                        )
                    }

                    // Smooth trend line overlay across the 7 days
                    if (pointOffsets.size >= 2) {
                        val linePath = Path().apply {
                            moveTo(pointOffsets[0].x, pointOffsets[0].y)
                            for (i in 1 until pointOffsets.size) {
                                val prev = pointOffsets[i - 1]
                                val curr = pointOffsets[i]
                                val midX = (prev.x + curr.x) / 2f
                                cubicTo(midX, prev.y, midX, curr.y, curr.x, curr.y)
                            }
                        }
                        drawPath(
                            path = linePath,
                            color = AmberGold.copy(alpha = 0.85f),
                            style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round)
                        )
                        pointOffsets.forEachIndexed { idx, pt ->
                            val isSel = idx == selectedIndex
                            drawCircle(
                                color = if (isSel) Color.White else AmberGold,
                                radius = if (isSel) 4.5.dp.toPx() else 3.dp.toPx(),
                                center = pt
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Legend row
            Row(
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                ChartLegendItem(color = accentColor, label = "اليوم")
                ChartLegendItem(color = secondaryColor, label = "أيام الأسبوع")
                ChartLegendItem(color = AmberGold, label = "منحنى الأداء")
            }
        }
    }
}

@Composable
private fun ChartLegendItem(color: Color, label: String) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Box(
            modifier = Modifier
                .size(10.dp)
                .background(color = color, shape = CircleShape)
        )
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = TextSecondary
        )
    }
}

private fun formatFocusDurationArabic(totalMinutes: Int): String {
    val hours = totalMinutes / 60
    val mins = totalMinutes % 60
    return when {
        hours > 0 && mins > 0 -> "$hours س و $mins د تركيز"
        hours > 0 -> "$hours ساعة تركيز"
        else -> "$mins دقيقة تركيز"
    }
}
