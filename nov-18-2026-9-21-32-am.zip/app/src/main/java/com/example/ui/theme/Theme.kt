package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val SakinaDarkColorScheme = darkColorScheme(
    primary = AmberGold,
    onPrimary = JadeDeep,
    primaryContainer = JadeSurfaceElevated,
    onPrimaryContainer = AmberGlow,
    secondary = SageMint,
    onSecondary = JadeDeep,
    secondaryContainer = JadeSurface,
    onSecondaryContainer = TextPrimary,
    tertiary = SoftLavender,
    onTertiary = JadeDeep,
    background = JadeDeep,
    onBackground = TextPrimary,
    surface = JadeSurface,
    onSurface = TextPrimary,
    surfaceVariant = JadeSurfaceElevated,
    onSurfaceVariant = TextSecondary,
    outline = GlassBorder,
    error = ErrorCoral,
    onError = JadeDeep
)

@Composable
fun SakinaTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = SakinaDarkColorScheme,
        typography = SakinaTypography,
        content = content
    )
}
