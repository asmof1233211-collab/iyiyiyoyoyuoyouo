package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.PomodoroPhase
import com.example.ui.theme.GlassDark
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun PomodoroTimerOrb(
    remainingSeconds: Int,
    progress: Float,
    phase: PomodoroPhase,
    isRunning: Boolean,
    accentColor: Color,
    secondaryColor: Color,
    orbSize: Dp,
    modifier: Modifier = Modifier
) {
    val animatedProgress by animateFloatAsState(
        targetValue = progress.coerceIn(0f, 1f),
        animationSpec = tween(durationMillis = 450, easing = FastOutSlowInEasing),
        label = "timer_progress"
    )

    val pulseTransition = rememberInfiniteTransition(label = "orb_pulse")
    val breathingGlow by pulseTransition.animateFloat(
        initialValue = 0.85f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "breathing_glow"
    )

    val minutes = remainingSeconds / 60
    val seconds = remainingSeconds % 60
    val formattedTime = "%02d:%02d".format(minutes, seconds)

    val isCompact = orbSize < 230.dp
    val timeFontSize = if (isCompact) 44.sp else 58.sp
    val strokeWidthDp = if (isCompact) 8.dp else 10.dp

    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .size(orbSize)
            .semantics {
                contentDescription = "${phase.arabicTitle} - الوقت المتبقي $formattedTime"
            }
    ) {
        Canvas(modifier = Modifier.size(orbSize)) {
            val strokePx = strokeWidthDp.toPx()
            val inset = strokePx * 1.45f
            val arcSize = Size(size.width - inset * 2, size.height - inset * 2)
            val topLeft = Offset(inset, inset)
            val center = Offset(size.width / 2f, size.height / 2f)
            val outerRadius = size.minDimension / 2f

            // Ambient radial halo when running
            val haloAlpha = if (isRunning) 0.24f * breathingGlow else 0.12f
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        accentColor.copy(alpha = haloAlpha),
                        secondaryColor.copy(alpha = haloAlpha * 0.35f),
                        Color.Transparent
                    ),
                    center = center,
                    radius = outerRadius
                ),
                radius = outerRadius,
                center = center
            )

            // Frosted translucent inner disc
            drawCircle(
                color = GlassDark.copy(alpha = 0.68f),
                radius = (arcSize.minDimension / 2f) - strokePx * 0.7f,
                center = center
            )

            // Subtle 60 dial ticks
            val tickOuter = (arcSize.minDimension / 2f) - strokePx * 1.05f
            for (i in 0 until 60) {
                val angleRad = (i * 6.0 - 90.0) * PI / 180.0
                val isMajor = i % 5 == 0
                val tickLen = if (isMajor) 9.dp.toPx() else 4.dp.toPx()
                val startR = tickOuter - tickLen
                val p1 = Offset(
                    center.x + (startR * cos(angleRad)).toFloat(),
                    center.y + (startR * sin(angleRad)).toFloat()
                )
                val p2 = Offset(
                    center.x + (tickOuter * cos(angleRad)).toFloat(),
                    center.y + (tickOuter * sin(angleRad)).toFloat()
                )
                drawLine(
                    color = Color.White.copy(alpha = if (isMajor) 0.35f else 0.14f),
                    start = p1,
                    end = p2,
                    strokeWidth = if (isMajor) 2f else 1.2f,
                    cap = StrokeCap.Round
                )
            }

            // Track ring
            drawArc(
                color = Color.White.copy(alpha = 0.14f),
                startAngle = 0f,
                sweepAngle = 360f,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokePx, cap = StrokeCap.Round)
            )

            // Luminous sweep progress arc
            val sweepAngle = animatedProgress * 360f
            if (sweepAngle > 0.5f) {
                drawArc(
                    brush = Brush.sweepGradient(
                        colors = listOf(secondaryColor, accentColor, secondaryColor),
                        center = center
                    ),
                    startAngle = -90f,
                    sweepAngle = sweepAngle,
                    useCenter = false,
                    topLeft = topLeft,
                    size = arcSize,
                    style = Stroke(width = strokePx, cap = StrokeCap.Round)
                )

                // Glowing head dot on progress tip
                val tipAngleRad = (-90.0 + sweepAngle) * PI / 180.0
                val ringRadius = arcSize.minDimension / 2f
                val tipOffset = Offset(
                    center.x + (ringRadius * cos(tipAngleRad)).toFloat(),
                    center.y + (ringRadius * sin(tipAngleRad)).toFloat()
                )
                drawCircle(
                    color = accentColor.copy(alpha = 0.45f),
                    radius = strokePx * 1.15f,
                    center = tipOffset
                )
                drawCircle(
                    color = Color.White,
                    radius = strokePx * 0.48f,
                    center = tipOffset
                )
            }
        }

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.padding(16.dp)
        ) {
            Text(
                text = phase.arabicTitle,
                style = MaterialTheme.typography.labelLarge,
                color = accentColor,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = formattedTime,
                style = MaterialTheme.typography.displayLarge.copy(fontSize = timeFontSize),
                color = TextPrimary
            )
            if (!isCompact) {
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = if (isRunning) phase.arabicSubtitle else "جاهز للبدء",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondary
                )
            }
        }
    }
}
