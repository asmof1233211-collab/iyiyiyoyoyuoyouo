package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material.icons.rounded.ScreenRotation
import androidx.compose.material.icons.rounded.StayCurrentLandscape
import androidx.compose.material.icons.rounded.StayCurrentPortrait
import androidx.compose.material.icons.rounded.Wallpaper
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.model.BackgroundCatalog
import com.example.model.BackgroundScene
import com.example.model.OrientationMode
import com.example.model.SceneAtmosphere
import com.example.ui.theme.AmberGold
import com.example.ui.theme.GlassBorder
import com.example.ui.theme.JadeDeep
import com.example.ui.theme.JadeSurface
import com.example.ui.theme.JadeSurfaceElevated
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BackgroundPickerSheet(
    selectedScene: BackgroundScene,
    isLandscape: Boolean,
    onSelectScene: (BackgroundScene) -> Unit,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = JadeSurface,
        contentColor = TextPrimary
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp)
                .padding(bottom = 24.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(
                    imageVector = Icons.Rounded.Wallpaper,
                    contentDescription = null,
                    tint = selectedScene.accentColor
                )
                Column {
                    Text(
                        text = "خلفيات المؤقت المريحة",
                        style = MaterialTheme.typography.titleLarge,
                        color = TextPrimary
                    )
                    Text(
                        text = "اختر مشهداً خيالياً أو طبيعياً أو أجواء أنمي للمذاكرة",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            LazyVerticalGrid(
                columns = GridCells.Fixed(if (isLandscape) 3 else 2),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(bottom = 8.dp),
                modifier = Modifier.height(if (isLandscape) 260.dp else 400.dp)
            ) {
                items(BackgroundCatalog.scenes, key = { it.id }) { scene ->
                    val isSelected = scene.id == selectedScene.id
                    Surface(
                        shape = RoundedCornerShape(18.dp),
                        border = BorderStroke(
                            width = if (isSelected) 2.5.dp else 1.dp,
                            color = if (isSelected) scene.accentColor else GlassBorder
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(145.dp)
                            .clip(RoundedCornerShape(18.dp))
                            .clickable { onSelectScene(scene) }
                            .testTag("bg_option_${scene.id}")
                    ) {
                        Box(modifier = Modifier.fillMaxSize()) {
                            if (scene.drawableRes != null) {
                                Image(
                                    painter = painterResource(id = scene.drawableRes),
                                    contentDescription = scene.titleArabic,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                            } else {
                                val gradColors = if (scene.atmosphere == SceneAtmosphere.AURORA_WAVES) {
                                    listOf(Color(0xFF071124), Color(0xFF103642), scene.accentColor.copy(alpha = 0.6f))
                                } else {
                                    listOf(Color(0xFF28243E), Color(0xFF8A5865), scene.accentColor.copy(alpha = 0.7f))
                                }
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .background(Brush.verticalGradient(gradColors))
                                )
                            }

                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(
                                        Brush.verticalGradient(
                                            colors = listOf(
                                                Color.Transparent,
                                                Color(0xD90A1211)
                                            )
                                        )
                                    )
                            )

                            if (isSelected) {
                                Icon(
                                    imageVector = Icons.Rounded.CheckCircle,
                                    contentDescription = "محدد",
                                    tint = scene.accentColor,
                                    modifier = Modifier
                                        .align(Alignment.TopEnd)
                                        .padding(10.dp)
                                        .size(22.dp)
                                        .background(JadeDeep.copy(alpha = 0.7f), CircleShape)
                                )
                            }

                            Column(
                                modifier = Modifier
                                    .align(Alignment.BottomStart)
                                    .padding(12.dp)
                            ) {
                                Text(
                                    text = scene.titleArabic,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = TextPrimary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = scene.subtitleArabic,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TextSecondary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TimerSettingsSheet(
    focusMinutes: Int,
    shortBreakMinutes: Int,
    longBreakMinutes: Int,
    orientationMode: OrientationMode,
    accentColor: Color,
    onUpdateDurations: (Int, Int, Int) -> Unit,
    onSelectOrientation: (OrientationMode) -> Unit,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = JadeSurface,
        contentColor = TextPrimary
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .navigationBarsPadding()
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = "إعدادات المؤقت والعرض",
                style = MaterialTheme.typography.titleLarge,
                color = TextPrimary
            )

            // Orientation Selector Card
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = JadeSurfaceElevated,
                border = BorderStroke(1.dp, GlassBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.ScreenRotation,
                            contentDescription = null,
                            tint = accentColor,
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = "شكل عرض المؤقت",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        OrientationOptionButton(
                            label = "وضع عمودي",
                            icon = Icons.Rounded.StayCurrentPortrait,
                            selected = orientationMode == OrientationMode.PORTRAIT,
                            accentColor = accentColor,
                            onClick = { onSelectOrientation(OrientationMode.PORTRAIT) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("settings_orientation_portrait")
                        )
                        OrientationOptionButton(
                            label = "وضع أفقي",
                            icon = Icons.Rounded.StayCurrentLandscape,
                            selected = orientationMode == OrientationMode.LANDSCAPE,
                            accentColor = accentColor,
                            onClick = { onSelectOrientation(OrientationMode.LANDSCAPE) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("settings_orientation_landscape")
                        )
                    }
                }
            }

            // Quick Focus Presets
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "قوالب سريعة لمدة التركيز",
                    style = MaterialTheme.typography.labelLarge,
                    color = TextSecondary
                )
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    listOf(25, 35, 45, 60).forEach { preset ->
                        val selected = focusMinutes == preset
                        FilterChip(
                            selected = selected,
                            onClick = { onUpdateDurations(preset, shortBreakMinutes, longBreakMinutes) },
                            label = { Text("$preset د") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = accentColor.copy(alpha = 0.25f),
                                selectedLabelColor = accentColor
                            )
                        )
                    }
                }
            }

            DurationStepperRow(
                title = "مدة التركيز",
                subtitle = "تظهر عبارة تحفيزية كل ١٠ دقائق",
                minutes = focusMinutes,
                accentColor = accentColor,
                onDecrement = {
                    if (focusMinutes > 5) onUpdateDurations(focusMinutes - 5, shortBreakMinutes, longBreakMinutes)
                },
                onIncrement = {
                    if (focusMinutes < 120) onUpdateDurations(focusMinutes + 5, shortBreakMinutes, longBreakMinutes)
                }
            )

            DurationStepperRow(
                title = "الاستراحة القصيرة",
                subtitle = "بين جلسات التركيز",
                minutes = shortBreakMinutes,
                accentColor = accentColor,
                onDecrement = {
                    if (shortBreakMinutes > 1) onUpdateDurations(focusMinutes, shortBreakMinutes - 1, longBreakMinutes)
                },
                onIncrement = {
                    if (shortBreakMinutes < 30) onUpdateDurations(focusMinutes, shortBreakMinutes + 1, longBreakMinutes)
                }
            )

            DurationStepperRow(
                title = "الاستراحة الطويلة",
                subtitle = "بعد ٤ جلسات تركيز",
                minutes = longBreakMinutes,
                accentColor = accentColor,
                onDecrement = {
                    if (longBreakMinutes > 5) onUpdateDurations(focusMinutes, shortBreakMinutes, longBreakMinutes - 5)
                },
                onIncrement = {
                    if (longBreakMinutes < 60) onUpdateDurations(focusMinutes, shortBreakMinutes, longBreakMinutes + 5)
                }
            )
        }
    }
}

@Composable
private fun OrientationOptionButton(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    selected: Boolean,
    accentColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = if (selected) accentColor.copy(alpha = 0.20f) else JadeDeep.copy(alpha = 0.5f),
        border = BorderStroke(1.dp, if (selected) accentColor else GlassBorder),
        modifier = modifier
            .height(52.dp)
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
            modifier = Modifier.padding(horizontal = 12.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (selected) accentColor else TextSecondary,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelLarge,
                color = if (selected) accentColor else TextPrimary,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
            )
        }
    }
}

@Composable
private fun DurationStepperRow(
    title: String,
    subtitle: String,
    minutes: Int,
    accentColor: Color,
    onDecrement: () -> Unit,
    onIncrement: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = JadeSurfaceElevated,
        border = BorderStroke(1.dp, GlassBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp)
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    color = TextPrimary
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondary
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = onDecrement,
                    modifier = Modifier.minimumInteractiveComponentSize()
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Remove,
                        contentDescription = "إنقاص $title",
                        tint = TextPrimary
                    )
                }
                Text(
                    text = "$minutes د",
                    style = MaterialTheme.typography.titleMedium,
                    color = accentColor,
                    modifier = Modifier.padding(horizontal = 8.dp)
                )
                IconButton(
                    onClick = onIncrement,
                    modifier = Modifier.minimumInteractiveComponentSize()
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Add,
                        contentDescription = "زيادة $title",
                        tint = AmberGold
                    )
                }
            }
        }
    }
}
