package com.example.ui.components

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.GlassBorder
import com.example.ui.theme.GlassCard
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun MotivationalQuoteBar(
    quote: String,
    secondsUntilNextQuote: Int,
    milestoneHighlighted: Boolean,
    accentColor: Color,
    isCompactLandscape: Boolean,
    onNextQuoteClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val borderColor by animateColorAsState(
        targetValue = if (milestoneHighlighted) accentColor else GlassBorder,
        animationSpec = tween(durationMillis = 600),
        label = "quote_border"
    )

    val minsLeft = secondsUntilNextQuote / 60
    val secsLeft = secondsUntilNextQuote % 60
    val countdownLabel = "%02d:%02d".format(minsLeft, secsLeft)

    Surface(
        shape = RoundedCornerShape(22.dp),
        color = GlassCard.copy(alpha = 0.72f),
        border = BorderStroke(if (milestoneHighlighted) 1.5.dp else 1.dp, borderColor),
        modifier = modifier
            .fillMaxWidth()
            .testTag("motivational_quote_card")
    ) {
        Column(
            modifier = Modifier.padding(
                horizontal = if (isCompactLandscape) 14.dp else 18.dp,
                vertical = if (isCompactLandscape) 10.dp else 14.dp
            )
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.AutoAwesome,
                        contentDescription = null,
                        tint = accentColor,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = if (milestoneHighlighted) "عبارة جديدة الآن" else "عبارة كل ١٠ دقائق",
                        style = MaterialTheme.typography.labelSmall,
                        color = accentColor
                    )
                    Text(
                        text = "•",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextMuted
                    )
                    Text(
                        text = "التالية خلال $countdownLabel",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary
                    )
                }

                IconButton(
                    onClick = onNextQuoteClick,
                    modifier = Modifier
                        .size(32.dp)
                        .minimumInteractiveComponentSize()
                        .testTag("next_quote_button")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Refresh,
                        contentDescription = "تغيير العبارة التحفيزية",
                        tint = TextSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(if (isCompactLandscape) 4.dp else 6.dp))

            AnimatedContent(
                targetState = quote,
                transitionSpec = {
                    (fadeIn(tween(450)) + slideInVertically(tween(450)) { it / 3 })
                        .togetherWith(fadeOut(tween(300)) + slideOutVertically(tween(300)) { -it / 3 })
                },
                label = "quote_transition"
            ) { targetQuote ->
                Text(
                    text = "« $targetQuote »",
                    style = MaterialTheme.typography.bodyLarge.copy(
                        fontSize = if (isCompactLandscape) 16.sp else 18.sp,
                        lineHeight = if (isCompactLandscape) 24.sp else 28.sp
                    ),
                    color = TextPrimary,
                    textAlign = TextAlign.Center,
                    maxLines = if (isCompactLandscape) 2 else 3,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 4.dp)
                )
            }
        }
    }
}
