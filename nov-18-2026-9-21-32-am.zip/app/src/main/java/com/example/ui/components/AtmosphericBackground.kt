package com.example.ui.components

import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import com.example.model.BackgroundScene
import com.example.model.SceneAtmosphere
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

private data class ParticleSeed(
    val xFrac: Float,
    val yFrac: Float,
    val radius: Float,
    val speed: Float,
    val phase: Float,
    val alpha: Float
)

@Composable
fun AtmosphericBackground(
    scene: BackgroundScene,
    isTimerRunning: Boolean,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "atmosphere")
    val animCycle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 16000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "cycle"
    )

    // Smooth continuous Ken Burns camera motion (zoom, drift & breathing tilt)
    val cameraPhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = (2f * PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 22000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "camera_phase"
    )

    val lightPulse by infiniteTransition.animateFloat(
        initialValue = 0.75f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 4200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "light_pulse"
    )

    val particles = remember {
        val rng = Random(42)
        List(44) {
            ParticleSeed(
                xFrac = rng.nextFloat(),
                yFrac = rng.nextFloat(),
                radius = 1.5f + rng.nextFloat() * 4.0f,
                speed = 0.45f + rng.nextFloat() * 1.15f,
                phase = rng.nextFloat() * (2f * PI.toFloat()),
                alpha = 0.28f + rng.nextFloat() * 0.65f
            )
        }
    }

    // Continuous Ken Burns motion parameters (scale >= 1.07 prevents exposing image edges)
    val motionFactor = if (isTimerRunning) 1.0f else 0.78f
    val zoomScale = 1.11f + 0.05f * sin(cameraPhase) * motionFactor
    val panX = 28f * cos(cameraPhase) * motionFactor
    val panY = 18f * sin(cameraPhase * 2f) * motionFactor
    val tiltDeg = 0.65f * sin(cameraPhase) * motionFactor

    Box(modifier = modifier.fillMaxSize().clipToBounds()) {
        Crossfade(
            targetState = scene,
            animationSpec = tween(durationMillis = 900),
            label = "scene_crossfade"
        ) { targetScene ->
            Box(modifier = Modifier.fillMaxSize().clipToBounds()) {
                if (targetScene.drawableRes != null) {
                    Image(
                        painter = painterResource(id = targetScene.drawableRes),
                        contentDescription = targetScene.titleArabic,
                        modifier = Modifier
                            .fillMaxSize()
                            .graphicsLayer {
                                scaleX = zoomScale
                                scaleY = zoomScale
                                translationX = panX
                                translationY = panY
                                rotationZ = tiltDeg
                            },
                        contentScale = ContentScale.Crop
                    )
                } else {
                    ProceduralSceneCanvas(
                        atmosphere = targetScene.atmosphere,
                        accent = targetScene.accentColor,
                        secondary = targetScene.secondaryColor,
                        cycle = animCycle
                    )
                }

                // Dynamic living light rays, drifting mist & particle overlay
                LivingParticlesOverlay(
                    atmosphere = targetScene.atmosphere,
                    accent = targetScene.accentColor,
                    secondary = targetScene.secondaryColor,
                    particles = particles,
                    cycle = animCycle,
                    lightPulse = lightPulse,
                    boost = if (isTimerRunning) 1.1f else 0.85f
                )

                // Balanced readability scrim so HUD & motivational quote stay crisp
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colorStops = arrayOf(
                                    0.0f to Color(0xA6081110),
                                    0.28f to Color(0x38081110),
                                    0.62f to Color(0x4D081110),
                                    1.0f to Color(0xCC070E0D)
                                )
                            )
                        )
                )
            }
        }
    }
}

@Composable
private fun ProceduralSceneCanvas(
    atmosphere: SceneAtmosphere,
    accent: Color,
    secondary: Color,
    cycle: Float
) {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        val t = cycle * 2f * PI.toFloat()

        if (atmosphere == SceneAtmosphere.AURORA_WAVES) {
            drawRect(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF060B18),
                        Color(0xFF0B1C2B),
                        Color(0xFF0E262B),
                        Color(0xFF071114)
                    )
                )
            )

            // Flowing aurora ribbons
            for (ribbon in 0..2) {
                val baseY = h * (0.24f + ribbon * 0.11f)
                val path = Path().apply {
                    moveTo(0f, baseY)
                    val steps = 20
                    for (i in 0..steps) {
                        val x = w * i / steps.toFloat()
                        val wave = sin(t + i * 0.42f + ribbon * 1.3f) * (h * 0.055f)
                        lineTo(x, baseY + wave)
                    }
                    lineTo(w, h * 0.72f)
                    lineTo(0f, h * 0.72f)
                    close()
                }
                val ribbonColor = if (ribbon % 2 == 0) accent else secondary
                drawPath(
                    path = path,
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            ribbonColor.copy(alpha = 0.24f),
                            ribbonColor.copy(alpha = 0.05f),
                            Color.Transparent
                        ),
                        startY = baseY - h * 0.08f,
                        endY = h * 0.72f
                    )
                )
            }

            // Layered mountain silhouettes
            drawMountainLayer(w, h, 0.70f, 0.06f, Color(0xFF0B1820), 0.7f)
            drawMountainLayer(w, h, 0.79f, 0.05f, Color(0xFF071015), 2.1f)
        } else {
            // DAWN_HILLS
            drawRect(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF1A1E33),
                        Color(0xFF42364E),
                        Color(0xFF8C5D68),
                        Color(0xFFDF9B78),
                        Color(0xFF281F26)
                    )
                )
            )
            val sunGlowY = h * 0.44f + sin(t) * (h * 0.01f)
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color(0x88FFE4B5),
                        accent.copy(alpha = 0.25f),
                        Color.Transparent
                    ),
                    center = Offset(w * 0.5f, sunGlowY),
                    radius = w * 0.45f
                ),
                center = Offset(w * 0.5f, sunGlowY),
                radius = w * 0.45f
            )
            drawMountainLayer(w, h, 0.66f, 0.05f, Color(0xFF4B3749), 1.1f)
            drawMountainLayer(w, h, 0.75f, 0.045f, Color(0xFF2D222E), 2.6f)
            drawMountainLayer(w, h, 0.84f, 0.035f, Color(0xFF18141C), 4.0f)
        }
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawMountainLayer(
    w: Float,
    h: Float,
    baseFrac: Float,
    ampFrac: Float,
    color: Color,
    seed: Float
) {
    val path = Path().apply {
        moveTo(0f, h)
        lineTo(0f, h * baseFrac)
        val steps = 16
        for (i in 0..steps) {
            val x = w * i / steps.toFloat()
            val ridge = (sin(i * 0.65f + seed) * 0.6f + cos(i * 1.15f + seed) * 0.4f) * (h * ampFrac)
            lineTo(x, h * baseFrac + ridge)
        }
        lineTo(w, h)
        close()
    }
    drawPath(path = path, color = color)
}

@Composable
private fun LivingParticlesOverlay(
    atmosphere: SceneAtmosphere,
    accent: Color,
    secondary: Color,
    particles: List<ParticleSeed>,
    cycle: Float,
    lightPulse: Float,
    boost: Float
) {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        val t = cycle * 2f * PI.toFloat()

        // Gentle breathing ambient light glow (simulates warm desk lamp / moonlight shimmer)
        val glowCenter = Offset(w * (0.5f + 0.08f * sin(t)), h * 0.36f)
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    accent.copy(alpha = 0.12f * lightPulse * boost),
                    secondary.copy(alpha = 0.04f * lightPulse),
                    Color.Transparent
                ),
                center = glowCenter,
                radius = w * 0.55f
            ),
            radius = w * 0.55f,
            center = glowCenter
        )

        when (atmosphere) {
            SceneAtmosphere.RAIN_STREAKS -> {
                particles.forEach { p ->
                    val travel = (p.yFrac + cycle * (2.2f + p.speed * 1.6f)) % 1.1f
                    val x = ((p.xFrac - travel * 0.14f + 1f) % 1f) * w
                    val y = travel * h
                    val len = 22f + p.radius * 8f
                    drawLine(
                        color = Color(0xFFBFE4F2).copy(alpha = p.alpha * 0.34f * boost),
                        start = Offset(x, y),
                        end = Offset(x - len * 0.16f, y + len),
                        strokeWidth = 1.6f,
                        cap = StrokeCap.Round
                    )
                }
            }

            SceneAtmosphere.STARLIGHT, SceneAtmosphere.AURORA_WAVES -> {
                particles.forEachIndexed { idx, p ->
                    val twinkle = 0.32f + 0.68f * (0.5f + 0.5f * sin(t * p.speed + p.phase))
                    val x = p.xFrac * w
                    val y = p.yFrac * h * 0.72f
                    val c = if (idx % 3 == 0) accent else Color.White
                    drawCircle(
                        color = c.copy(alpha = p.alpha * twinkle * 0.7f * boost),
                        radius = p.radius * 0.75f,
                        center = Offset(x, y)
                    )
                }
                // Soft periodic shooting star shimmer
                val meteorProgress = (cycle * 2.5f) % 1f
                if (meteorProgress < 0.25f) {
                    val mFrac = meteorProgress / 0.25f
                    val mx = w * (0.85f - mFrac * 0.45f)
                    val my = h * (0.12f + mFrac * 0.22f)
                    drawLine(
                        color = Color.White.copy(alpha = (1f - mFrac) * 0.55f),
                        start = Offset(mx, my),
                        end = Offset(mx + 42f, my - 20f),
                        strokeWidth = 2f,
                        cap = StrokeCap.Round
                    )
                }
            }

            else -> {
                // FIREFLIES, CLOUD_SHIMMER, DAWN_HILLS
                particles.forEachIndexed { idx, p ->
                    val y = ((p.yFrac - cycle * p.speed * 0.42f + 1f) % 1f) * h
                    val driftX = sin(t * 0.9f + p.phase) * 28f
                    val x = (p.xFrac * w + driftX).coerceIn(0f, w)
                    val pulse = 0.4f + 0.6f * (0.5f + 0.5f * sin(t * 1.6f + p.phase))
                    val c = if (idx % 2 == 0) accent else secondary
                    drawCircle(
                        color = c.copy(alpha = p.alpha * pulse * 0.48f * boost),
                        radius = p.radius * 2.2f,
                        center = Offset(x, y)
                    )
                    drawCircle(
                        color = Color.White.copy(alpha = p.alpha * pulse * 0.6f * boost),
                        radius = p.radius * 0.7f,
                        center = Offset(x, y)
                    )
                }
            }
        }
    }
}
