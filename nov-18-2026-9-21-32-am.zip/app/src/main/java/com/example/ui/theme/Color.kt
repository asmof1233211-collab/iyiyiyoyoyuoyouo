package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val JadeDeep = Color(0xFF0E1A18)
val JadeSurface = Color(0xFF162623)
val JadeSurfaceElevated = Color(0xFF1F332F)

val AmberGold = Color(0xFFE7BA73)
val AmberGlow = Color(0xFFF6D59B)
val SageMint = Color(0xFF8FD3B4)
val MistTeal = Color(0xFF63B3A6)
val SoftLavender = Color(0xFFC5B3E6)
val RoseDusk = Color(0xFFE8A89A)

val TextPrimary = Color(0xFFF7F5EF)
val TextSecondary = Color(0xFFD0D8D4)
val TextMuted = Color(0xFF9AA8A2)

val GlassDark = Color(0x990D1615)
val GlassCard = Color(0x8014201E)
val GlassBorder = Color(0x3DFFFFFF)
val ErrorCoral = Color(0xFFE57373)
