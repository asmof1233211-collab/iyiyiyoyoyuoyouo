package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Air
import androidx.compose.material.icons.rounded.Forest
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.LocalFireDepartment
import androidx.compose.material.icons.rounded.MenuBook
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.VolumeOff
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material.icons.rounded.WaterDrop
import androidx.compose.material.icons.rounded.Waves
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.model.AmbientSoundType
import com.example.model.QuranCatalog
import com.example.model.QuranPlaybackStatus
import com.example.ui.theme.ErrorCoral
import com.example.ui.theme.GlassBorder
import com.example.ui.theme.JadeDeep
import com.example.ui.theme.JadeSurface
import com.example.ui.theme.JadeSurfaceElevated
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.SoundTrackState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SoundMixerSheet(
    sounds: Map<AmbientSoundType, SoundTrackState>,
    isMasterMuted: Boolean,
    selectedSurahNumber: Int,
    selectedReciterId: String,
    quranStatus: QuranPlaybackStatus,
    accentColor: Color,
    onToggleSound: (AmbientSoundType) -> Unit,
    onVolumeChange: (AmbientSoundType, Float) -> Unit,
    onSelectQuran: (Int, String) -> Unit,
    onToggleMasterMute: () -> Unit,
    onStopAllSounds: () -> Unit,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val activeCount = sounds.values.count { it.isEnabled }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = JadeSurface,
        contentColor = TextPrimary
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp)
                .padding(bottom = 16.dp)
        ) {
            // Header row
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "مكتبة الأصوات والمزج",
                        style = MaterialTheme.typography.titleLarge,
                        color = TextPrimary
                    )
                    Text(
                        text = if (activeCount == 0) {
                            "امزج المطر والحطب والعود أو استمع للقرآن الكريم"
                        } else {
                            "يعمل الآن $activeCount ${if (activeCount == 1) "صوت" else "أصوات"}"
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    IconButton(
                        onClick = onToggleMasterMute,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("master_mute_button")
                    ) {
                        Icon(
                            imageVector = if (isMasterMuted) Icons.Rounded.VolumeOff else Icons.Rounded.VolumeUp,
                            contentDescription = if (isMasterMuted) "إلغاء كتم الصوت" else "كتم كل الأصوات",
                            tint = if (isMasterMuted) ErrorCoral else accentColor
                        )
                    }
                    if (activeCount > 0) {
                        OutlinedButton(
                            onClick = onStopAllSounds,
                            border = BorderStroke(1.dp, GlassBorder),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Stop,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp),
                                tint = TextSecondary
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "إيقاف",
                                style = MaterialTheme.typography.labelLarge,
                                color = TextSecondary
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 20.dp),
                modifier = Modifier.height(430.dp)
            ) {
                items(AmbientSoundType.entries, key = { it.id }) { soundType ->
                    val trackState = sounds[soundType] ?: SoundTrackState(soundType)
                    SoundTrackCard(
                        soundType = soundType,
                        trackState = trackState,
                        selectedSurahNumber = selectedSurahNumber,
                        selectedReciterId = selectedReciterId,
                        quranStatus = quranStatus,
                        accentColor = accentColor,
                        onToggle = { onToggleSound(soundType) },
                        onVolumeChange = { onVolumeChange(soundType, it) },
                        onSelectQuran = onSelectQuran
                    )
                }
            }
        }
    }
}

@Composable
private fun SoundTrackCard(
    soundType: AmbientSoundType,
    trackState: SoundTrackState,
    selectedSurahNumber: Int,
    selectedReciterId: String,
    quranStatus: QuranPlaybackStatus,
    accentColor: Color,
    onToggle: () -> Unit,
    onVolumeChange: (Float) -> Unit,
    onSelectQuran: (Int, String) -> Unit
) {
    val active = trackState.isEnabled
    Surface(
        shape = RoundedCornerShape(18.dp),
        color = if (active) accentColor.copy(alpha = 0.14f) else JadeSurfaceElevated,
        border = BorderStroke(1.dp, if (active) accentColor else GlassBorder),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("sound_card_${soundType.id}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Surface(
                        shape = CircleShape,
                        color = if (active) accentColor else JadeDeep,
                        modifier = Modifier.size(42.dp)
                    ) {
                        Icon(
                            imageVector = iconForSound(soundType),
                            contentDescription = null,
                            tint = if (active) JadeDeep else accentColor,
                            modifier = Modifier.padding(9.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = soundType.titleArabic,
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary
                        )
                        Text(
                            text = soundType.descriptionArabic,
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondary
                        )
                    }
                }

                if (soundType.isStreamingQuran && active && quranStatus == QuranPlaybackStatus.BUFFERING) {
                    CircularProgressIndicator(
                        color = accentColor,
                        strokeWidth = 2.dp,
                        modifier = Modifier
                            .padding(end = 8.dp)
                            .size(20.dp)
                    )
                }

                Switch(
                    checked = active,
                    onCheckedChange = { onToggle() },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = JadeDeep,
                        checkedTrackColor = accentColor,
                        uncheckedThumbColor = TextSecondary,
                        uncheckedTrackColor = JadeDeep
                    ),
                    modifier = Modifier.testTag("sound_switch_${soundType.id}")
                )
            }

            // Quran Surah & Reciter picker
            if (soundType.isStreamingQuran) {
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "اختر السورة:",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondary
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.horizontalScroll(rememberScrollState())
                ) {
                    QuranCatalog.surahs.forEach { surah ->
                        val isChosen = surah.number == selectedSurahNumber
                        FilterChip(
                            selected = isChosen,
                            onClick = { onSelectQuran(surah.number, selectedReciterId) },
                            label = {
                                Text(
                                    text = surah.nameArabic,
                                    style = MaterialTheme.typography.labelLarge
                                )
                            },
                            leadingIcon = if (isChosen && active) {
                                {
                                    Icon(
                                        imageVector = if (quranStatus == QuranPlaybackStatus.PLAYING) {
                                            Icons.Rounded.Pause
                                        } else {
                                            Icons.Rounded.PlayArrow
                                        },
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            } else null,
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = accentColor.copy(alpha = 0.28f),
                                selectedLabelColor = accentColor,
                                selectedLeadingIconColor = accentColor
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "القارئ:",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondary
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.horizontalScroll(rememberScrollState())
                ) {
                    QuranCatalog.reciters.forEach { reciter ->
                        val isChosen = reciter.editionId == selectedReciterId
                        FilterChip(
                            selected = isChosen,
                            onClick = { onSelectQuran(selectedSurahNumber, reciter.editionId) },
                            label = {
                                Text(
                                    text = reciter.nameArabic,
                                    style = MaterialTheme.typography.labelSmall
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = accentColor.copy(alpha = 0.22f),
                                selectedLabelColor = accentColor
                            )
                        )
                    }
                }

                if (active && quranStatus == QuranPlaybackStatus.ERROR) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "تعذّر تحميل التلاوة — تأكد من اتصال الإنترنت ثم أعد المحاولة",
                        style = MaterialTheme.typography.labelSmall,
                        color = ErrorCoral
                    )
                }
            }

            // Individual volume slider
            AnimatedVisibility(visible = active) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.VolumeUp,
                        contentDescription = null,
                        tint = accentColor,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Slider(
                        value = trackState.volume,
                        onValueChange = onVolumeChange,
                        valueRange = 0.05f..1f,
                        colors = SliderDefaults.colors(
                            thumbColor = accentColor,
                            activeTrackColor = accentColor,
                            inactiveTrackColor = TextMuted.copy(alpha = 0.35f)
                        ),
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "${(trackState.volume * 100).toInt()}%",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary
                    )
                }
            }
        }
    }
}

private fun iconForSound(type: AmbientSoundType): ImageVector = when (type) {
    AmbientSoundType.RAIN -> Icons.Rounded.WaterDrop
    AmbientSoundType.FIREPLACE -> Icons.Rounded.LocalFireDepartment
    AmbientSoundType.QURAN -> Icons.Rounded.MenuBook
    AmbientSoundType.OUD -> Icons.Rounded.MusicNote
    AmbientSoundType.OCEAN -> Icons.Rounded.Waves
    AmbientSoundType.FOREST_BIRDS -> Icons.Rounded.Forest
    AmbientSoundType.NEY_DRONE -> Icons.Rounded.Air
    AmbientSoundType.BROWN_NOISE -> Icons.Rounded.GraphicEq
}
