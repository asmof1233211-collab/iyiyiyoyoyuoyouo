package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.BarChart
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.RestartAlt
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.StayCurrentLandscape
import androidx.compose.material.icons.rounded.StayCurrentPortrait
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.VolumeOff
import androidx.compose.material.icons.rounded.Wallpaper
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.model.OrientationMode
import com.example.model.PomodoroPhase
import com.example.model.QuranCatalog
import com.example.ui.components.AtmosphericBackground
import com.example.ui.components.BackgroundPickerSheet
import com.example.ui.components.FocusStatsSheet
import com.example.ui.components.MotivationalQuoteBar
import com.example.ui.components.PomodoroTimerOrb
import com.example.ui.components.SoundMixerSheet
import com.example.ui.components.TimerSettingsSheet
import com.example.ui.theme.GlassBorder
import com.example.ui.theme.GlassCard
import com.example.ui.theme.GlassDark
import com.example.ui.theme.JadeDeep
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.PomodoroUiState

@Composable
fun PomodoroScreen(
    state: PomodoroUiState,
    onToggleStartPause: () -> Unit,
    onResetTimer: () -> Unit,
    onSelectPhase: (PomodoroPhase) -> Unit,
    onToggleOrientation: () -> Unit,
    onSelectOrientation: (OrientationMode) -> Unit,
    onSelectBackground: (com.example.model.BackgroundScene) -> Unit,
    onUpdateDurations: (Int, Int, Int) -> Unit,
    onNextQuote: () -> Unit,
    onToggleSound: (com.example.model.AmbientSoundType) -> Unit,
    onVolumeChange: (com.example.model.AmbientSoundType, Float) -> Unit,
    onSelectQuran: (Int, String) -> Unit,
    onToggleMasterMute: () -> Unit,
    onStopAllSounds: () -> Unit,
    onDismissSessionBanner: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showBackgroundSheet by rememberSaveable { mutableStateOf(false) }
    var showSoundSheet by rememberSaveable { mutableStateOf(false) }
    var showSettingsSheet by rememberSaveable { mutableStateOf(false) }
    var showStatsSheet by rememberSaveable { mutableStateOf(false) }

    val accent = state.currentBackground.accentColor
    val secondary = state.currentBackground.secondaryColor

    Box(modifier = modifier.fillMaxSize()) {
        // Fullscreen fantasy/natural atmospheric background
        AtmosphericBackground(
            scene = state.currentBackground,
            isTimerRunning = state.isRunning
        )

        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .padding(horizontal = 16.dp, vertical = 10.dp)
        ) {
            val isLandscapeLayout =
                maxWidth > maxHeight || state.orientationMode == OrientationMode.LANDSCAPE

            if (isLandscapeLayout) {
                LandscapeStudioLayout(
                    state = state,
                    accent = accent,
                    secondary = secondary,
                    availableHeight = maxHeight,
                    onToggleStartPause = onToggleStartPause,
                    onResetTimer = onResetTimer,
                    onSelectPhase = onSelectPhase,
                    onToggleOrientation = onToggleOrientation,
                    onOpenStats = { showStatsSheet = true },
                    onOpenBackgrounds = { showBackgroundSheet = true },
                    onOpenSounds = { showSoundSheet = true },
                    onOpenSettings = { showSettingsSheet = true },
                    onNextQuote = onNextQuote,
                    onDismissBanner = onDismissSessionBanner
                )
            } else {
                PortraitStudioLayout(
                    state = state,
                    accent = accent,
                    secondary = secondary,
                    availableWidth = maxWidth,
                    onToggleStartPause = onToggleStartPause,
                    onResetTimer = onResetTimer,
                    onSelectPhase = onSelectPhase,
                    onToggleOrientation = onToggleOrientation,
                    onOpenStats = { showStatsSheet = true },
                    onOpenBackgrounds = { showBackgroundSheet = true },
                    onOpenSounds = { showSoundSheet = true },
                    onOpenSettings = { showSettingsSheet = true },
                    onNextQuote = onNextQuote,
                    onDismissBanner = onDismissSessionBanner
                )
            }
        }
    }

    if (showBackgroundSheet) {
        BackgroundPickerSheet(
            selectedScene = state.currentBackground,
            isLandscape = state.orientationMode == OrientationMode.LANDSCAPE,
            onSelectScene = onSelectBackground,
            onDismiss = { showBackgroundSheet = false }
        )
    }

    if (showSoundSheet) {
        SoundMixerSheet(
            sounds = state.sounds,
            isMasterMuted = state.isMasterMuted,
            selectedSurahNumber = state.selectedSurahNumber,
            selectedReciterId = state.selectedReciterId,
            quranStatus = state.quranPlaybackStatus,
            accentColor = accent,
            onToggleSound = onToggleSound,
            onVolumeChange = onVolumeChange,
            onSelectQuran = onSelectQuran,
            onToggleMasterMute = onToggleMasterMute,
            onStopAllSounds = onStopAllSounds,
            onDismiss = { showSoundSheet = false }
        )
    }

    if (showSettingsSheet) {
        TimerSettingsSheet(
            focusMinutes = state.focusMinutes,
            shortBreakMinutes = state.shortBreakMinutes,
            longBreakMinutes = state.longBreakMinutes,
            orientationMode = state.orientationMode,
            accentColor = accent,
            onUpdateDurations = onUpdateDurations,
            onSelectOrientation = onSelectOrientation,
            onDismiss = { showSettingsSheet = false }
        )
    }

    if (showStatsSheet) {
        FocusStatsSheet(
            weeklyStats = state.weeklyStats,
            todaySessions = state.todaySessions,
            todayMinutes = state.todayFocusMinutes,
            weekSessions = state.weekSessions,
            weekMinutes = state.weekFocusMinutes,
            totalLifetimeSessions = state.completedSessions,
            accentColor = accent,
            secondaryColor = secondary,
            onDismiss = { showStatsSheet = false }
        )
    }
}

@Composable
private fun PortraitStudioLayout(
    state: PomodoroUiState,
    accent: Color,
    secondary: Color,
    availableWidth: androidx.compose.ui.unit.Dp,
    onToggleStartPause: () -> Unit,
    onResetTimer: () -> Unit,
    onSelectPhase: (PomodoroPhase) -> Unit,
    onToggleOrientation: () -> Unit,
    onOpenStats: () -> Unit,
    onOpenBackgrounds: () -> Unit,
    onOpenSounds: () -> Unit,
    onOpenSettings: () -> Unit,
    onNextQuote: () -> Unit,
    onDismissBanner: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier
            .fillMaxSize()
            .navigationBarsPadding()
    ) {
        TopHudBar(
            state = state,
            accent = accent,
            isCompact = false,
            onOpenStats = onOpenStats,
            onToggleOrientation = onToggleOrientation,
            onOpenBackgrounds = onOpenBackgrounds,
            onOpenSounds = onOpenSounds,
            onOpenSettings = onOpenSettings
        )

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier
                .widthIn(max = 560.dp)
                .fillMaxWidth()
        ) {
            AnimatedVisibility(
                visible = state.sessionCompletedBanner,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                SessionCompletePill(
                    phase = state.phase,
                    accent = accent,
                    onDismiss = onDismissBanner
                )
            }

            PhaseSelectorRow(
                currentPhase = state.phase,
                accent = accent,
                onSelectPhase = onSelectPhase
            )

            val orbSize = (availableWidth * 0.68f).coerceIn(220.dp, 290.dp)
            PomodoroTimerOrb(
                remainingSeconds = state.remainingSeconds,
                progress = state.progress,
                phase = state.phase,
                isRunning = state.isRunning,
                accentColor = accent,
                secondaryColor = secondary,
                orbSize = orbSize
            )

            TimerControlsRow(
                isRunning = state.isRunning,
                accent = accent,
                onToggleStartPause = onToggleStartPause,
                onResetTimer = onResetTimer,
                onNextPhase = {
                    val next = when (state.phase) {
                        PomodoroPhase.FOCUS -> PomodoroPhase.SHORT_BREAK
                        PomodoroPhase.SHORT_BREAK -> PomodoroPhase.LONG_BREAK
                        PomodoroPhase.LONG_BREAK -> PomodoroPhase.FOCUS
                    }
                    onSelectPhase(next)
                }
            )

            ActiveAudioStatusPill(
                state = state,
                accent = accent,
                onClick = onOpenSounds
            )
        }

        MotivationalQuoteBar(
            quote = state.currentQuote,
            secondsUntilNextQuote = state.secondsUntilNextQuote,
            milestoneHighlighted = state.quoteMilestoneJustReached,
            accentColor = accent,
            isCompactLandscape = false,
            onNextQuoteClick = onNextQuote,
            modifier = Modifier.widthIn(max = 580.dp)
        )
    }
}

@Composable
private fun LandscapeStudioLayout(
    state: PomodoroUiState,
    accent: Color,
    secondary: Color,
    availableHeight: androidx.compose.ui.unit.Dp,
    onToggleStartPause: () -> Unit,
    onResetTimer: () -> Unit,
    onSelectPhase: (PomodoroPhase) -> Unit,
    onToggleOrientation: () -> Unit,
    onOpenStats: () -> Unit,
    onOpenBackgrounds: () -> Unit,
    onOpenSounds: () -> Unit,
    onOpenSettings: () -> Unit,
    onNextQuote: () -> Unit,
    onDismissBanner: () -> Unit
) {
    Column(
        verticalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier
            .fillMaxSize()
            .navigationBarsPadding()
    ) {
        TopHudBar(
            state = state,
            accent = accent,
            isCompact = true,
            onOpenStats = onOpenStats,
            onToggleOrientation = onToggleOrientation,
            onOpenBackgrounds = onOpenBackgrounds,
            onOpenSounds = onOpenSounds,
            onOpenSettings = onOpenSettings
        )

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(20.dp),
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(vertical = 4.dp)
        ) {
            // Side 1: Luminous Timer Orb
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .weight(0.95f)
                    .fillMaxHeight()
            ) {
                val orbSize = (availableHeight * 0.62f).coerceIn(165.dp, 235.dp)
                PomodoroTimerOrb(
                    remainingSeconds = state.remainingSeconds,
                    progress = state.progress,
                    phase = state.phase,
                    isRunning = state.isRunning,
                    accentColor = accent,
                    secondaryColor = secondary,
                    orbSize = orbSize
                )
            }

            // Side 2: Mode switcher, Controls, Active Sound Pill & 10-Min Quote
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceEvenly,
                modifier = Modifier
                    .weight(1.15f)
                    .fillMaxHeight()
            ) {
                AnimatedVisibility(visible = state.sessionCompletedBanner) {
                    SessionCompletePill(
                        phase = state.phase,
                        accent = accent,
                        onDismiss = onDismissBanner
                    )
                }

                PhaseSelectorRow(
                    currentPhase = state.phase,
                    accent = accent,
                    onSelectPhase = onSelectPhase
                )

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    TimerControlsRow(
                        isRunning = state.isRunning,
                        accent = accent,
                        onToggleStartPause = onToggleStartPause,
                        onResetTimer = onResetTimer,
                        onNextPhase = {
                            val next = when (state.phase) {
                                PomodoroPhase.FOCUS -> PomodoroPhase.SHORT_BREAK
                                PomodoroPhase.SHORT_BREAK -> PomodoroPhase.LONG_BREAK
                                PomodoroPhase.LONG_BREAK -> PomodoroPhase.FOCUS
                            }
                            onSelectPhase(next)
                        }
                    )
                }

                ActiveAudioStatusPill(
                    state = state,
                    accent = accent,
                    onClick = onOpenSounds
                )

                MotivationalQuoteBar(
                    quote = state.currentQuote,
                    secondsUntilNextQuote = state.secondsUntilNextQuote,
                    milestoneHighlighted = state.quoteMilestoneJustReached,
                    accentColor = accent,
                    isCompactLandscape = true,
                    onNextQuoteClick = onNextQuote
                )
            }
        }
    }
}

@Composable
private fun TopHudBar(
    state: PomodoroUiState,
    accent: Color,
    isCompact: Boolean,
    onOpenStats: () -> Unit,
    onToggleOrientation: () -> Unit,
    onOpenBackgrounds: () -> Unit,
    onOpenSounds: () -> Unit,
    onOpenSettings: () -> Unit
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier.fillMaxWidth()
    ) {
        // Brand + Clickable Sessions Stats Pill
        Surface(
            shape = RoundedCornerShape(50),
            color = GlassCard,
            border = BorderStroke(1.dp, GlassBorder),
            modifier = Modifier
                .clip(RoundedCornerShape(50))
                .clickable(onClick = onOpenStats)
                .minimumInteractiveComponentSize()
                .testTag("open_stats_button")
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp)
            ) {
                Text(
                    text = "مؤقت سارة",
                    style = MaterialTheme.typography.titleMedium,
                    color = accent
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "•",
                    color = TextSecondary
                )
                Spacer(modifier = Modifier.width(6.dp))
                Icon(
                    imageVector = Icons.Rounded.BarChart,
                    contentDescription = "إحصائيات التركيز",
                    tint = accent,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "${state.completedSessions} جلسات",
                    style = MaterialTheme.typography.labelLarge,
                    color = TextPrimary
                )
            }
        }

        // Action pills: Orientation Toggle, Backgrounds, Sounds, Timer Settings
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Portrait / Landscape Mode Switcher Pill
            Surface(
                shape = RoundedCornerShape(50),
                color = GlassCard,
                border = BorderStroke(1.dp, accent.copy(alpha = 0.55f)),
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .clickable(onClick = onToggleOrientation)
                    .minimumInteractiveComponentSize()
                    .testTag("orientation_toggle_button")
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Icon(
                        imageVector = if (state.orientationMode == OrientationMode.PORTRAIT) {
                            Icons.Rounded.StayCurrentLandscape
                        } else {
                            Icons.Rounded.StayCurrentPortrait
                        },
                        contentDescription = "تبديل الوضع الأفقي والعمودي",
                        tint = accent,
                        modifier = Modifier.size(18.dp)
                    )
                    if (!isCompact) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (state.orientationMode == OrientationMode.PORTRAIT) "أفقي" else "عمودي",
                            style = MaterialTheme.typography.labelLarge,
                            color = TextPrimary
                        )
                    }
                }
            }

            // Backgrounds Picker
            GlassIconButton(
                icon = Icons.Rounded.Wallpaper,
                contentDescription = "تغيير الخلفية",
                tint = TextPrimary,
                onClick = onOpenBackgrounds,
                modifier = Modifier.testTag("open_backgrounds_button")
            )

            // Sounds Mixer with active count badge
            BadgedBox(
                badge = {
                    if (state.activeSoundCount > 0) {
                        Badge(
                            containerColor = accent,
                            contentColor = JadeDeep
                        ) {
                            Text(state.activeSoundCount.toString())
                        }
                    }
                }
            ) {
                GlassIconButton(
                    icon = if (state.isMasterMuted) Icons.Rounded.VolumeOff else Icons.Rounded.MusicNote,
                    contentDescription = "قائمة الأصوات",
                    tint = if (state.activeSoundCount > 0 && !state.isMasterMuted) accent else TextPrimary,
                    onClick = onOpenSounds,
                    modifier = Modifier.testTag("open_sounds_button")
                )
            }

            // Timer Settings
            GlassIconButton(
                icon = Icons.Rounded.Tune,
                contentDescription = "إعدادات المؤقت",
                tint = TextPrimary,
                onClick = onOpenSettings,
                modifier = Modifier.testTag("open_settings_button")
            )
        }
    }
}

@Composable
private fun GlassIconButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    contentDescription: String,
    tint: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = CircleShape,
        color = GlassCard,
        border = BorderStroke(1.dp, GlassBorder),
        modifier = modifier
            .size(44.dp)
            .minimumInteractiveComponentSize()
    ) {
        IconButton(onClick = onClick) {
            Icon(
                imageVector = icon,
                contentDescription = contentDescription,
                tint = tint,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

@Composable
private fun PhaseSelectorRow(
    currentPhase: PomodoroPhase,
    accent: Color,
    onSelectPhase: (PomodoroPhase) -> Unit
) {
    Surface(
        shape = RoundedCornerShape(50),
        color = GlassDark.copy(alpha = 0.72f),
        border = BorderStroke(1.dp, GlassBorder)
    ) {
        Row(
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            modifier = Modifier
                .horizontalScroll(rememberScrollState())
                .padding(4.dp)
        ) {
            PomodoroPhase.entries.forEach { phase ->
                val selected = phase == currentPhase
                Surface(
                    shape = RoundedCornerShape(50),
                    color = if (selected) accent else Color.Transparent,
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .clickable { onSelectPhase(phase) }
                        .testTag("phase_${phase.name}")
                ) {
                    Text(
                        text = phase.arabicTitle,
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                        color = if (selected) JadeDeep else TextSecondary,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun TimerControlsRow(
    isRunning: Boolean,
    accent: Color,
    onToggleStartPause: () -> Unit,
    onResetTimer: () -> Unit,
    onNextPhase: () -> Unit
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        FilledTonalIconButton(
            onClick = onResetTimer,
            colors = IconButtonDefaults.filledTonalIconButtonColors(
                containerColor = GlassCard,
                contentColor = TextPrimary
            ),
            modifier = Modifier
                .size(48.dp)
                .testTag("reset_timer_button")
        ) {
            Icon(
                imageVector = Icons.Rounded.RestartAlt,
                contentDescription = "إعادة ضبط المؤقت"
            )
        }

        Button(
            onClick = onToggleStartPause,
            shape = RoundedCornerShape(50),
            colors = ButtonDefaults.buttonColors(
                containerColor = accent,
                contentColor = JadeDeep
            ),
            modifier = Modifier
                .height(54.dp)
                .widthIn(min = 148.dp)
                .testTag("play_pause_button")
        ) {
            Icon(
                imageVector = if (isRunning) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                contentDescription = null,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = if (isRunning) "إيقاف مؤقت" else "ابدأ الجلسة",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }

        FilledTonalIconButton(
            onClick = onNextPhase,
            colors = IconButtonDefaults.filledTonalIconButtonColors(
                containerColor = GlassCard,
                contentColor = TextPrimary
            ),
            modifier = Modifier
                .size(48.dp)
                .testTag("next_phase_button")
        ) {
            Icon(
                imageVector = Icons.Rounded.SkipNext,
                contentDescription = "المرحلة التالية"
            )
        }
    }
}

@Composable
private fun ActiveAudioStatusPill(
    state: PomodoroUiState,
    accent: Color,
    onClick: () -> Unit
) {
    val activeTracks = state.sounds.values.filter { it.isEnabled }
    val summaryText = when {
        state.isMasterMuted && activeTracks.isNotEmpty() -> "الأصوات مكتومة مؤقتاً"
        activeTracks.isEmpty() -> "قائمة الأصوات: المطر، الحطب، القرآن، العود..."
        else -> activeTracks.joinToString(" • ") { track ->
            if (track.type.isStreamingQuran) {
                val surah = QuranCatalog.surahs.firstOrNull { it.number == state.selectedSurahNumber }
                surah?.nameArabic ?: track.type.titleArabic
            } else {
                track.type.titleArabic
            }
        }
    }

    Surface(
        shape = RoundedCornerShape(50),
        color = GlassCard,
        border = BorderStroke(
            width = 1.dp,
            color = if (activeTracks.isNotEmpty()) accent.copy(alpha = 0.65f) else GlassBorder
        ),
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .clickable(onClick = onClick)
            .minimumInteractiveComponentSize()
            .testTag("active_audio_pill")
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
        ) {
            Icon(
                imageVector = Icons.Rounded.MusicNote,
                contentDescription = null,
                tint = if (activeTracks.isNotEmpty()) accent else TextSecondary,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = summaryText,
                style = MaterialTheme.typography.labelLarge,
                color = if (activeTracks.isNotEmpty()) TextPrimary else TextSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.widthIn(max = 260.dp)
            )
        }
    }
}

@Composable
private fun SessionCompletePill(
    phase: PomodoroPhase,
    accent: Color,
    onDismiss: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = accent.copy(alpha = 0.22f),
        border = BorderStroke(1.dp, accent),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Icon(
                    imageVector = Icons.Rounded.CheckCircle,
                    contentDescription = null,
                    tint = accent,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "أحسنت! حان وقت: ${phase.arabicTitle}",
                    style = MaterialTheme.typography.labelLarge,
                    color = TextPrimary
                )
            }
            IconButton(
                onClick = onDismiss,
                modifier = Modifier.size(28.dp)
            ) {
                Icon(
                    imageVector = Icons.Rounded.Close,
                    contentDescription = "إغلاق",
                    tint = TextSecondary,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}
