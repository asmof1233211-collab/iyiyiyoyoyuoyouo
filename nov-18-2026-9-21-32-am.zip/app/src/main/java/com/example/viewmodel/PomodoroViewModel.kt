package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.AmbientAudioEngine
import com.example.data.PreferencesRepository
import com.example.model.AmbientSoundType
import com.example.model.BackgroundCatalog
import com.example.model.BackgroundScene
import com.example.model.DailyFocusStat
import com.example.model.MotivationalQuotes
import com.example.model.OrientationMode
import com.example.model.PomodoroPhase
import com.example.model.QuranPlaybackStatus
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class SoundTrackState(
    val type: AmbientSoundType,
    val isEnabled: Boolean = false,
    val volume: Float = type.defaultVolume
)

data class PomodoroUiState(
    val phase: PomodoroPhase = PomodoroPhase.FOCUS,
    val focusMinutes: Int = 25,
    val shortBreakMinutes: Int = 5,
    val longBreakMinutes: Int = 15,
    val totalSeconds: Int = 25 * 60,
    val remainingSeconds: Int = 25 * 60,
    val isRunning: Boolean = false,
    val orientationMode: OrientationMode = OrientationMode.PORTRAIT,
    val currentBackground: BackgroundScene = BackgroundCatalog.scenes.first(),
    val quoteIndex: Int = 0,
    val cumulativeFocusSeconds: Int = 0,
    val secondsUntilNextQuote: Int = 600,
    val quoteMilestoneJustReached: Boolean = false,
    val completedSessions: Int = 0,
    val totalFocusMinutes: Int = 0,
    val weeklyStats: List<DailyFocusStat> = PreferencesRepository.buildLastSevenDays(emptyMap()),
    val sounds: Map<AmbientSoundType, SoundTrackState> = AmbientSoundType.entries.associateWith {
        SoundTrackState(type = it, isEnabled = false, volume = it.defaultVolume)
    },
    val isMasterMuted: Boolean = false,
    val selectedSurahNumber: Int = 55,
    val selectedReciterId: String = "ar.alafasy",
    val quranPlaybackStatus: QuranPlaybackStatus = QuranPlaybackStatus.IDLE,
    val sessionCompletedBanner: Boolean = false
) {
    val activeSoundCount: Int
        get() = sounds.values.count { it.isEnabled }

    val progress: Float
        get() = if (totalSeconds > 0) {
            1f - (remainingSeconds.toFloat() / totalSeconds.toFloat())
        } else 0f

    val currentQuote: String
        get() = MotivationalQuotes.phrases[quoteIndex % MotivationalQuotes.phrases.size]

    val todaySessions: Int
        get() = weeklyStats.lastOrNull { it.isToday }?.sessions ?: 0

    val todayFocusMinutes: Int
        get() = weeklyStats.lastOrNull { it.isToday }?.minutes ?: 0

    val weekSessions: Int
        get() = weeklyStats.sumOf { it.sessions }

    val weekFocusMinutes: Int
        get() = weeklyStats.sumOf { it.minutes }
}

class PomodoroViewModel(application: Application) : AndroidViewModel(application) {

    companion object {
        const val MOTIVATIONAL_INTERVAL_SECONDS = 600 // 10 minutes
    }

    private val repository = PreferencesRepository(application.applicationContext)
    private val audioEngine = AmbientAudioEngine()

    private val _uiState = MutableStateFlow(PomodoroUiState())
    val uiState: StateFlow<PomodoroUiState> = _uiState.asStateFlow()

    private var timerJob: Job? = null
    private var initialLoaded = false

    init {
        viewModelScope.launch {
            repository.settingsFlow.collect { saved ->
                _uiState.update { state ->
                    if (!initialLoaded) {
                        initialLoaded = true
                        val focusSec = saved.focusMinutes * 60
                        state.copy(
                            focusMinutes = saved.focusMinutes,
                            shortBreakMinutes = saved.shortBreakMinutes,
                            longBreakMinutes = saved.longBreakMinutes,
                            totalSeconds = focusSec,
                            remainingSeconds = focusSec,
                            orientationMode = saved.orientationMode,
                            currentBackground = BackgroundCatalog.byId(saved.backgroundId),
                            completedSessions = saved.completedSessions,
                            totalFocusMinutes = saved.totalFocusMinutes,
                            selectedSurahNumber = saved.selectedSurahNumber,
                            selectedReciterId = saved.selectedReciterId,
                            weeklyStats = saved.weeklyStats
                        )
                    } else {
                        state.copy(
                            completedSessions = saved.completedSessions,
                            totalFocusMinutes = saved.totalFocusMinutes,
                            weeklyStats = saved.weeklyStats
                        )
                    }
                }
            }
        }

        viewModelScope.launch {
            audioEngine.quranStatus.collect { status ->
                _uiState.update { it.copy(quranPlaybackStatus = status) }
            }
        }
    }

    fun toggleStartPause() {
        val currentlyRunning = _uiState.value.isRunning
        if (currentlyRunning) {
            pauseTimer()
        } else {
            startTimer()
        }
    }

    private fun startTimer() {
        if (timerJob?.isActive == true) return
        _uiState.update { it.copy(isRunning = true, sessionCompletedBanner = false) }
        timerJob = viewModelScope.launch {
            while (_uiState.value.isRunning && _uiState.value.remainingSeconds > 0) {
                delay(1000L)
                if (!_uiState.value.isRunning) break
                onTimerTick()
            }
        }
    }

    private fun pauseTimer() {
        timerJob?.cancel()
        timerJob = null
        _uiState.update { it.copy(isRunning = false) }
    }

    private fun onTimerTick() {
        val current = _uiState.value
        val nextRemaining = (current.remainingSeconds - 1).coerceAtLeast(0)
        val isFocus = current.phase == PomodoroPhase.FOCUS
        val nextCumulativeFocus = if (isFocus) current.cumulativeFocusSeconds + 1 else current.cumulativeFocusSeconds

        val hitTenMinuteMark = isFocus &&
            nextCumulativeFocus > 0 &&
            nextCumulativeFocus % MOTIVATIONAL_INTERVAL_SECONDS == 0

        val nextQuoteIndex = if (hitTenMinuteMark) {
            (current.quoteIndex + 1) % MotivationalQuotes.phrases.size
        } else {
            current.quoteIndex
        }

        val remainder = nextCumulativeFocus % MOTIVATIONAL_INTERVAL_SECONDS
        val nextCountdown = if (remainder == 0 && nextCumulativeFocus > 0) {
            MOTIVATIONAL_INTERVAL_SECONDS
        } else {
            MOTIVATIONAL_INTERVAL_SECONDS - remainder
        }

        if (hitTenMinuteMark && !current.isMasterMuted) {
            audioEngine.playGentleBell()
        }

        _uiState.update {
            it.copy(
                remainingSeconds = nextRemaining,
                cumulativeFocusSeconds = nextCumulativeFocus,
                secondsUntilNextQuote = nextCountdown,
                quoteIndex = nextQuoteIndex,
                quoteMilestoneJustReached = hitTenMinuteMark || it.quoteMilestoneJustReached
            )
        }

        if (hitTenMinuteMark) {
            viewModelScope.launch {
                delay(4000L)
                _uiState.update { it.copy(quoteMilestoneJustReached = false) }
            }
        }

        if (nextRemaining == 0) {
            onPhaseCompleted()
        }
    }

    private fun onPhaseCompleted() {
        pauseTimer()
        val finishedPhase = _uiState.value.phase
        if (!_uiState.value.isMasterMuted) {
            audioEngine.playGentleBell()
        }

        if (finishedPhase == PomodoroPhase.FOCUS) {
            val addedMinutes = _uiState.value.focusMinutes
            viewModelScope.launch {
                repository.recordCompletedFocusSession(addedMinutes)
            }
            val nextCompleted = _uiState.value.completedSessions + 1
            val nextPhase = if (nextCompleted % 4 == 0) {
                PomodoroPhase.LONG_BREAK
            } else {
                PomodoroPhase.SHORT_BREAK
            }
            val nextSeconds = durationForPhase(nextPhase, _uiState.value) * 60
            _uiState.update {
                it.copy(
                    completedSessions = nextCompleted,
                    totalFocusMinutes = it.totalFocusMinutes + addedMinutes,
                    phase = nextPhase,
                    totalSeconds = nextSeconds,
                    remainingSeconds = nextSeconds,
                    sessionCompletedBanner = true
                )
            }
        } else {
            val nextSeconds = _uiState.value.focusMinutes * 60
            _uiState.update {
                it.copy(
                    phase = PomodoroPhase.FOCUS,
                    totalSeconds = nextSeconds,
                    remainingSeconds = nextSeconds,
                    sessionCompletedBanner = true
                )
            }
        }
    }

    fun resetTimer() {
        pauseTimer()
        val state = _uiState.value
        val seconds = durationForPhase(state.phase, state) * 60
        _uiState.update {
            it.copy(
                totalSeconds = seconds,
                remainingSeconds = seconds,
                sessionCompletedBanner = false
            )
        }
    }

    fun selectPhase(phase: PomodoroPhase) {
        pauseTimer()
        val state = _uiState.value
        val seconds = durationForPhase(phase, state) * 60
        _uiState.update {
            it.copy(
                phase = phase,
                totalSeconds = seconds,
                remainingSeconds = seconds,
                sessionCompletedBanner = false
            )
        }
    }

    fun updateDurations(focus: Int, shortBreak: Int, longBreak: Int) {
        val clampedFocus = focus.coerceIn(5, 120)
        val clampedShort = shortBreak.coerceIn(1, 30)
        val clampedLong = longBreak.coerceIn(5, 60)

        viewModelScope.launch {
            repository.setDurations(clampedFocus, clampedShort, clampedLong)
        }

        val current = _uiState.value
        val updatedState = current.copy(
            focusMinutes = clampedFocus,
            shortBreakMinutes = clampedShort,
            longBreakMinutes = clampedLong
        )
        if (!current.isRunning) {
            val sec = durationForPhase(current.phase, updatedState) * 60
            _uiState.value = updatedState.copy(totalSeconds = sec, remainingSeconds = sec)
        } else {
            _uiState.value = updatedState
        }
    }

    fun toggleOrientation() {
        val next = if (_uiState.value.orientationMode == OrientationMode.PORTRAIT) {
            OrientationMode.LANDSCAPE
        } else {
            OrientationMode.PORTRAIT
        }
        setOrientation(next)
    }

    fun setOrientation(mode: OrientationMode) {
        _uiState.update { it.copy(orientationMode = mode) }
        viewModelScope.launch {
            repository.setOrientationMode(mode)
        }
    }

    fun selectBackground(scene: BackgroundScene) {
        _uiState.update { it.copy(currentBackground = scene) }
        viewModelScope.launch {
            repository.setBackgroundId(scene.id)
        }
    }

    fun nextMotivationalQuote() {
        _uiState.update {
            it.copy(quoteIndex = (it.quoteIndex + 1) % MotivationalQuotes.phrases.size)
        }
    }

    fun toggleSound(type: AmbientSoundType) {
        val currentMap = _uiState.value.sounds.toMutableMap()
        val currentTrack = currentMap[type] ?: SoundTrackState(type)
        val nextEnabled = !currentTrack.isEnabled
        currentMap[type] = currentTrack.copy(isEnabled = nextEnabled)
        _uiState.update { it.copy(sounds = currentMap) }

        val state = _uiState.value
        audioEngine.setSoundState(
            type = type,
            enabled = nextEnabled,
            volume = currentTrack.volume,
            surahNumber = state.selectedSurahNumber,
            reciterId = state.selectedReciterId
        )
    }

    fun setSoundVolume(type: AmbientSoundType, volume: Float) {
        val clamped = volume.coerceIn(0f, 1f)
        val currentMap = _uiState.value.sounds.toMutableMap()
        val currentTrack = currentMap[type] ?: SoundTrackState(type)
        val shouldEnable = if (clamped > 0.02f) currentTrack.isEnabled else currentTrack.isEnabled
        currentMap[type] = currentTrack.copy(volume = clamped, isEnabled = shouldEnable)
        _uiState.update { it.copy(sounds = currentMap) }

        val state = _uiState.value
        if (shouldEnable) {
            audioEngine.setSoundState(
                type = type,
                enabled = true,
                volume = clamped,
                surahNumber = state.selectedSurahNumber,
                reciterId = state.selectedReciterId
            )
        }
    }

    fun selectQuranSurahAndReciter(surahNumber: Int, reciterId: String) {
        _uiState.update {
            it.copy(selectedSurahNumber = surahNumber, selectedReciterId = reciterId)
        }
        viewModelScope.launch {
            repository.setQuranSelection(surahNumber, reciterId)
        }
        val quranTrack = _uiState.value.sounds[AmbientSoundType.QURAN]
        if (quranTrack?.isEnabled == true) {
            audioEngine.updateQuranSelection(surahNumber, reciterId)
        } else {
            // Auto-start Quran when user picks a Surah from the Quran section
            val currentMap = _uiState.value.sounds.toMutableMap()
            val track = currentMap[AmbientSoundType.QURAN] ?: SoundTrackState(AmbientSoundType.QURAN)
            currentMap[AmbientSoundType.QURAN] = track.copy(isEnabled = true)
            _uiState.update { it.copy(sounds = currentMap) }
            audioEngine.setSoundState(
                type = AmbientSoundType.QURAN,
                enabled = true,
                volume = track.volume,
                surahNumber = surahNumber,
                reciterId = reciterId
            )
        }
    }

    fun toggleMasterMute() {
        val next = !_uiState.value.isMasterMuted
        _uiState.update { it.copy(isMasterMuted = next) }
        audioEngine.setMasterMuted(next)
    }

    fun stopAllSounds() {
        val resetMap = _uiState.value.sounds.mapValues { (_, track) ->
            track.copy(isEnabled = false)
        }
        _uiState.update { it.copy(sounds = resetMap) }
        audioEngine.stopAll()
    }

    fun dismissSessionBanner() {
        _uiState.update { it.copy(sessionCompletedBanner = false) }
    }

    private fun durationForPhase(phase: PomodoroPhase, state: PomodoroUiState): Int = when (phase) {
        PomodoroPhase.FOCUS -> state.focusMinutes
        PomodoroPhase.SHORT_BREAK -> state.shortBreakMinutes
        PomodoroPhase.LONG_BREAK -> state.longBreakMinutes
    }

    override fun onCleared() {
        super.onCleared()
        timerJob?.cancel()
        audioEngine.release()
    }
}
