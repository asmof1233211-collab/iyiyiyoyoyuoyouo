package com.example.model

import androidx.annotation.DrawableRes
import androidx.compose.ui.graphics.Color
import com.example.R

enum class PomodoroPhase(
    val arabicTitle: String,
    val arabicSubtitle: String,
    val defaultMinutes: Int
) {
    FOCUS("تركيز عميق", "تفرغ لإنجازك بهدوء", 25),
    SHORT_BREAK("استراحة قصيرة", "تنفّس بعمق وجدّد نشاطك", 5),
    LONG_BREAK("استراحة طويلة", "كافئ نفسك بلحظة صفاء", 15)
}

enum class OrientationMode(val arabicLabel: String) {
    PORTRAIT("عمودي"),
    LANDSCAPE("أفقي")
}

enum class SceneAtmosphere {
    FIREFLIES,
    CLOUD_SHIMMER,
    RAIN_STREAKS,
    STARLIGHT,
    AURORA_WAVES,
    DAWN_HILLS
}

data class BackgroundScene(
    val id: String,
    val titleArabic: String,
    val subtitleArabic: String,
    @DrawableRes val drawableRes: Int?,
    val accentColor: Color,
    val secondaryColor: Color,
    val atmosphere: SceneAtmosphere
)

object BackgroundCatalog {
    val scenes: List<BackgroundScene> = listOf(
        BackgroundScene(
            id = "cosmic_nebula",
            titleArabic = "مجرة السديم",
            subtitleArabic = "سدم كونية ساحرة ونجوم متحركة",
            drawableRes = R.drawable.img_bg_cosmic_nebula,
            accentColor = Color(0xFF7BE8DF),
            secondaryColor = Color(0xFFD09CFF),
            atmosphere = SceneAtmosphere.STARLIGHT
        ),
        BackgroundScene(
            id = "neon_rain_city",
            titleArabic = "مدينة الأضواء والمطر",
            subtitleArabic = "شرفة ليلية مطلة على أضواء المدينة تحت المطر",
            drawableRes = R.drawable.img_bg_neon_rain_city,
            accentColor = Color(0xFF6FE3F5),
            secondaryColor = Color(0xFFF592D0),
            atmosphere = SceneAtmosphere.RAIN_STREAKS
        ),
        BackgroundScene(
            id = "anime_night_study",
            titleArabic = "دراسة ليلية (أنمي)",
            subtitleArabic = "كتابة ومذاكرة هادئة تحت ضوء القمر",
            drawableRes = R.drawable.img_bg_anime_night_study,
            accentColor = Color(0xFFF4C57A),
            secondaryColor = Color(0xFF9EB5FF),
            atmosphere = SceneAtmosphere.STARLIGHT
        ),
        BackgroundScene(
            id = "anime_rainy_study",
            titleArabic = "مذاكرة المطر (أنمي)",
            subtitleArabic = "تدوين وتركيز مع صوت المطر",
            drawableRes = R.drawable.img_bg_anime_rainy_study,
            accentColor = Color(0xFFB5E0C2),
            secondaryColor = Color(0xFFF2C88B),
            atmosphere = SceneAtmosphere.RAIN_STREAKS
        ),
        BackgroundScene(
            id = "enchanted_forest",
            titleArabic = "غابة السحر",
            subtitleArabic = "أشجار هادئة وأضواء متلألئة",
            drawableRes = R.drawable.img_bg_enchanted_forest,
            accentColor = Color(0xFF95E0B0),
            secondaryColor = Color(0xFFEBD288),
            atmosphere = SceneAtmosphere.FIREFLIES
        ),
        BackgroundScene(
            id = "rainy_cabin",
            titleArabic = "كوخ المطر",
            subtitleArabic = "نافذة دافئة على غابة ممطرة",
            drawableRes = R.drawable.img_bg_rainy_cabin,
            accentColor = Color(0xFFF0BE6F),
            secondaryColor = Color(0xFF79A7B3),
            atmosphere = SceneAtmosphere.RAIN_STREAKS
        ),
        BackgroundScene(
            id = "floating_islands",
            titleArabic = "جزر السحاب",
            subtitleArabic = "شلالات حالمة فوق الغيوم",
            drawableRes = R.drawable.img_bg_floating_islands,
            accentColor = Color(0xFFF7C9A9),
            secondaryColor = Color(0xFFCBB5EE),
            atmosphere = SceneAtmosphere.CLOUD_SHIMMER
        ),
        BackgroundScene(
            id = "celestial_oasis",
            titleArabic = "واحة النجوم",
            subtitleArabic = "ليلة صحراوية صافية تحت الشفق",
            drawableRes = R.drawable.img_bg_celestial_oasis,
            accentColor = Color(0xFF8EC9FF),
            secondaryColor = Color(0xFFF3C677),
            atmosphere = SceneAtmosphere.STARLIGHT
        ),
        BackgroundScene(
            id = "aurora_night",
            titleArabic = "شفق الشمال",
            subtitleArabic = "أضواء قطبية متحركة في سكون الليل",
            drawableRes = null,
            accentColor = Color(0xFF72E8C6),
            secondaryColor = Color(0xFF9C8CFF),
            atmosphere = SceneAtmosphere.AURORA_WAVES
        ),
        BackgroundScene(
            id = "dawn_oasis",
            titleArabic = "أفق الفجر",
            subtitleArabic = "تلال هادئة مع نسيم الشروق",
            drawableRes = null,
            accentColor = Color(0xFFF3C685),
            secondaryColor = Color(0xFFE09D8C),
            atmosphere = SceneAtmosphere.DAWN_HILLS
        )
    )

    fun byId(id: String): BackgroundScene =
        scenes.firstOrNull { it.id == id } ?: scenes.first()
}

enum class AmbientSoundType(
    val id: String,
    val titleArabic: String,
    val descriptionArabic: String,
    val defaultVolume: Float,
    val isStreamingQuran: Boolean = false
) {
    RAIN(
        id = "rain",
        titleArabic = "المطر الهادئ",
        descriptionArabic = "هطول مطر لطيف يبعث على السكينة",
        defaultVolume = 0.65f
    ),
    FIREPLACE(
        id = "fireplace",
        titleArabic = "دفء الحطب",
        descriptionArabic = "طقطقة نار هادئة في مدفأة دافئة",
        defaultVolume = 0.60f
    ),
    QURAN(
        id = "quran",
        titleArabic = "القرآن الكريم",
        descriptionArabic = "تلاوة عطرة تهدئ القلب والعقل",
        defaultVolume = 0.75f,
        isStreamingQuran = true
    ),
    OUD(
        id = "oud",
        titleArabic = "العود العربي",
        descriptionArabic = "تقاسيم عود شرقية هادئة ومريحة",
        defaultVolume = 0.55f
    ),
    OCEAN(
        id = "ocean",
        titleArabic = "أمواج البحر",
        descriptionArabic = "تلاطم أمواج لطيفة على الشاطئ",
        defaultVolume = 0.55f
    ),
    FOREST_BIRDS(
        id = "forest_birds",
        titleArabic = "نسيم الغابة",
        descriptionArabic = "حفيف أوراق الشجر مع تغريد لطيف",
        defaultVolume = 0.50f
    ),
    NEY_DRONE(
        id = "ney_drone",
        titleArabic = "الناي التأملي",
        descriptionArabic = "أنغام ناي دافئة للتأمل العميق",
        defaultVolume = 0.50f
    ),
    BROWN_NOISE(
        id = "brown_noise",
        titleArabic = "همس التركيز",
        descriptionArabic = "ضوضاء دافئة تعزل التشتت والضجيج",
        defaultVolume = 0.50f
    )
}

data class QuranSurah(
    val number: Int,
    val nameArabic: String,
    val subtitleArabic: String
)

data class QuranReciter(
    val editionId: String,
    val nameArabic: String
)

object QuranCatalog {
    val surahs = listOf(
        QuranSurah(55, "سورة الرحمن", "آيات السكينة والتأمل"),
        QuranSurah(67, "سورة الملك", "تلاوة مطمئنة"),
        QuranSurah(36, "سورة يس", "قلب القرآن الكريم"),
        QuranSurah(18, "سورة الكهف", "نور وبركة في يومك"),
        QuranSurah(73, "سورة المزمل", "خشوع وصفاء ذهني"),
        QuranSurah(93, "سورة الضحى", "بشرى وطمأنينة"),
        QuranSurah(56, "سورة الواقعة", "تلاوة متأنية"),
        QuranSurah(1, "سورة الفاتحة", "أم الكتاب")
    )

    val reciters = listOf(
        QuranReciter("ar.alafasy", "مشاري راشد العفاسي"),
        QuranReciter("ar.husary", "محمود خليل الحصري"),
        QuranReciter("ar.mahermuaiqly", "ماهر المعيقلي"),
        QuranReciter("ar.abdulbasitmurattal", "عبد الباسط عبد الصمد")
    )

    fun primaryUrl(reciterId: String, surahNumber: Int): String =
        "https://cdn.islamic.network/quran/audio-surah/128/$reciterId/$surahNumber.mp3"

    fun fallbackUrl(surahNumber: Int): String {
        val padded = surahNumber.toString().padStart(3, '0')
        return "https://server8.mp3quran.net/afs/$padded.mp3"
    }
}

enum class QuranPlaybackStatus {
    IDLE,
    BUFFERING,
    PLAYING,
    ERROR
}

object MotivationalQuotes {
    val phrases: List<String> = listOf(
        "عشر دقائق من التركيز الصادق تصنع فرقاً لا تصنعه ساعات من التشتت.",
        "ابدأ حيث أنت، واستعن بالهدوء، فالإنجاز العظيم يُبنى خطوةً تلو خطوة.",
        "صفاء ذهنك هو أثمن ما تملك في هذه اللحظة؛ احفظه من الضجيج.",
        "كل دقيقة تقضيها في التعلم والعمل المتقن هي بذرةٌ لمستقبلٍ يليق بك.",
        "لا تستعجل الثمرة، بل أتقن السقي؛ فالاستمرارية الهادئة تهزم الاندفاع المؤقت.",
        "السكينة ليست غياب التحديات، بل حضور التركيز والثقة وسط كل المهام.",
        "تذكّر أن التقدّم الصغير كل يوم يتراكم ليصبح إنجازاً مذهلاً.",
        "توقف لتتنفس بعمق، ثم أكمِل؛ فالعقل المرتاح أكثر إبداعاً ووضوحاً.",
        "من أتقن حاضره استقبل مستقبله مطمئناً؛ اجعل هذه الجلسة خالصةً لهدفك.",
        "الهمة العالية لا تحتاج إلى صخب، يكفيها قلبٌ ثابت ونيةٌ صافية.",
        "كل عائقٍ أمامك اليوم هو تدريبٌ صامت لقوة إرادتك غداً.",
        "أعطِ مهمتك الحالية كامل انتباهك، وستندهش من سرعة انسياب الأفكار.",
        "ما زرعته في لحظات الجدّ والتركيز ستحصده راحةً وفخراً عند التمام.",
        "الفارق بين الحلم والواقع هو التزامك بهذه الدقائق القليلة الآن.",
        "احفظ وقتك كما تحفظ كنزك، فالساعات تمضي ولكن الأثر الجميل يبقى.",
        "اجعل الجودة رفيقك والهدوء طريقك، فما كان لله وللخير دام وأثمر.",
        "أنت أقرب إلى هدفك مما تظن؛ استمر بذات الشغف والاتزان.",
        "تعلّم أن تستمتع برحلة الإنجاز نفسها، لا بلحظة النهاية فحسب.",
        "النظام في الوقت يمنحك حريةً في الفكر واتساعاً في الإبداع.",
        "ثق بقدرتك على إتمام ما بدأت، فالبدايات الصادقة تقود إلى خواتيم مشرقة."
    )
}

data class DailyFocusStat(
    val dateKey: String,
    val dayLabelArabic: String,
    val sessions: Int,
    val minutes: Int,
    val isToday: Boolean
)

