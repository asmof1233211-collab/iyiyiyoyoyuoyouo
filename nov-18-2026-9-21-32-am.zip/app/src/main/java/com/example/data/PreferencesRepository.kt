package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.model.DailyFocusStat
import com.example.model.OrientationMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "sakina_prefs")

data class PersistedSettings(
    val backgroundId: String = "enchanted_forest",
    val orientationMode: OrientationMode = OrientationMode.PORTRAIT,
    val focusMinutes: Int = 25,
    val shortBreakMinutes: Int = 5,
    val longBreakMinutes: Int = 15,
    val completedSessions: Int = 0,
    val totalFocusMinutes: Int = 0,
    val selectedSurahNumber: Int = 55,
    val selectedReciterId: String = "ar.alafasy",
    val weeklyStats: List<DailyFocusStat> = emptyList()
)

class PreferencesRepository(private val context: Context) {

    private object Keys {
        val BACKGROUND_ID = stringPreferencesKey("background_id")
        val ORIENTATION_MODE = stringPreferencesKey("orientation_mode")
        val FOCUS_MINUTES = intPreferencesKey("focus_minutes")
        val SHORT_BREAK_MINUTES = intPreferencesKey("short_break_minutes")
        val LONG_BREAK_MINUTES = intPreferencesKey("long_break_minutes")
        val COMPLETED_SESSIONS = intPreferencesKey("completed_sessions")
        val TOTAL_FOCUS_MINUTES = intPreferencesKey("total_focus_minutes")
        val SELECTED_SURAH = intPreferencesKey("selected_surah")
        val SELECTED_RECITER = stringPreferencesKey("selected_reciter")
        val DAILY_HISTORY = stringPreferencesKey("daily_focus_history")
    }

    val settingsFlow: Flow<PersistedSettings> = context.dataStore.data.map { prefs ->
        val orientRaw = prefs[Keys.ORIENTATION_MODE] ?: OrientationMode.PORTRAIT.name
        val orientation = OrientationMode.entries.firstOrNull { it.name == orientRaw }
            ?: OrientationMode.PORTRAIT
        val historyMap = parseHistory(prefs[Keys.DAILY_HISTORY].orEmpty())
        PersistedSettings(
            backgroundId = prefs[Keys.BACKGROUND_ID] ?: "enchanted_forest",
            orientationMode = orientation,
            focusMinutes = (prefs[Keys.FOCUS_MINUTES] ?: 25).coerceIn(5, 120),
            shortBreakMinutes = (prefs[Keys.SHORT_BREAK_MINUTES] ?: 5).coerceIn(1, 30),
            longBreakMinutes = (prefs[Keys.LONG_BREAK_MINUTES] ?: 15).coerceIn(5, 60),
            completedSessions = prefs[Keys.COMPLETED_SESSIONS] ?: 0,
            totalFocusMinutes = prefs[Keys.TOTAL_FOCUS_MINUTES] ?: 0,
            selectedSurahNumber = prefs[Keys.SELECTED_SURAH] ?: 55,
            selectedReciterId = prefs[Keys.SELECTED_RECITER] ?: "ar.alafasy",
            weeklyStats = buildLastSevenDays(historyMap)
        )
    }

    suspend fun setBackgroundId(id: String) {
        context.dataStore.edit { it[Keys.BACKGROUND_ID] = id }
    }

    suspend fun setOrientationMode(mode: OrientationMode) {
        context.dataStore.edit { it[Keys.ORIENTATION_MODE] = mode.name }
    }

    suspend fun setDurations(focus: Int, shortBreak: Int, longBreak: Int) {
        context.dataStore.edit {
            it[Keys.FOCUS_MINUTES] = focus.coerceIn(5, 120)
            it[Keys.SHORT_BREAK_MINUTES] = shortBreak.coerceIn(1, 30)
            it[Keys.LONG_BREAK_MINUTES] = longBreak.coerceIn(5, 60)
        }
    }

    suspend fun recordCompletedFocusSession(minutesAdded: Int) {
        context.dataStore.edit { prefs ->
            val currentSessions = prefs[Keys.COMPLETED_SESSIONS] ?: 0
            val currentMinutes = prefs[Keys.TOTAL_FOCUS_MINUTES] ?: 0
            prefs[Keys.COMPLETED_SESSIONS] = currentSessions + 1
            prefs[Keys.TOTAL_FOCUS_MINUTES] = currentMinutes + minutesAdded

            val historyMap = parseHistory(prefs[Keys.DAILY_HISTORY].orEmpty()).toMutableMap()
            val todayKey = todayDateKey()
            val existing = historyMap[todayKey] ?: (0 to 0)
            historyMap[todayKey] = (existing.first + 1) to (existing.second + minutesAdded)
            prefs[Keys.DAILY_HISTORY] = serializeHistory(historyMap)
        }
    }

    suspend fun setQuranSelection(surahNumber: Int, reciterId: String) {
        context.dataStore.edit {
            it[Keys.SELECTED_SURAH] = surahNumber
            it[Keys.SELECTED_RECITER] = reciterId
        }
    }

    companion object {
        private val dateFormatter = SimpleDateFormat("yyyy-MM-dd", Locale.US)

        fun todayDateKey(): String = synchronized(dateFormatter) {
            dateFormatter.format(Calendar.getInstance().time)
        }

        fun buildLastSevenDays(history: Map<String, Pair<Int, Int>>): List<DailyFocusStat> {
            val cal = Calendar.getInstance()
            cal.add(Calendar.DAY_OF_YEAR, -6)
            val result = mutableListOf<DailyFocusStat>()
            val todayKey = todayDateKey()

            for (offset in 0..6) {
                val key = synchronized(dateFormatter) { dateFormatter.format(cal.time) }
                val entry = history[key] ?: (0 to 0)
                val isToday = key == todayKey
                val label = if (isToday) "اليوم" else arabicDayShortName(cal.get(Calendar.DAY_OF_WEEK))
                result.add(
                    DailyFocusStat(
                        dateKey = key,
                        dayLabelArabic = label,
                        sessions = entry.first,
                        minutes = entry.second,
                        isToday = isToday
                    )
                )
                cal.add(Calendar.DAY_OF_YEAR, 1)
            }
            return result
        }

        private fun arabicDayShortName(dayOfWeek: Int): String = when (dayOfWeek) {
            Calendar.SATURDAY -> "السبت"
            Calendar.SUNDAY -> "الأحد"
            Calendar.MONDAY -> "الاثنين"
            Calendar.TUESDAY -> "الثلاثاء"
            Calendar.WEDNESDAY -> "الأربعاء"
            Calendar.THURSDAY -> "الخميس"
            Calendar.FRIDAY -> "الجمعة"
            else -> ""
        }

        private fun parseHistory(raw: String): Map<String, Pair<Int, Int>> {
            if (raw.isBlank()) return emptyMap()
            val map = linkedMapOf<String, Pair<Int, Int>>()
            raw.split("|").forEach { token ->
                val parts = token.split(":")
                if (parts.size == 3) {
                    val date = parts[0]
                    val sessions = parts[1].toIntOrNull() ?: 0
                    val minutes = parts[2].toIntOrNull() ?: 0
                    if (date.isNotBlank()) {
                        map[date] = sessions to minutes
                    }
                }
            }
            return map
        }

        private fun serializeHistory(history: Map<String, Pair<Int, Int>>): String {
            return history.entries
                .sortedBy { it.key }
                .takeLast(30)
                .joinToString("|") { (date, pair) -> "$date:${pair.first}:${pair.second}" }
        }
    }
}
