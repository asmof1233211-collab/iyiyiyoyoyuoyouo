package com.example

import android.content.pm.ActivityInfo
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.model.OrientationMode
import com.example.ui.PomodoroScreen
import com.example.ui.theme.SakinaTheme
import com.example.viewmodel.PomodoroViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val viewModel: PomodoroViewModel = viewModel()
            val state by viewModel.uiState.collectAsStateWithLifecycle()

            LaunchedEffect(state.orientationMode) {
                requestedOrientation = when (state.orientationMode) {
                    OrientationMode.PORTRAIT -> ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                    OrientationMode.LANDSCAPE -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                }
            }

            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                SakinaTheme {
                    PomodoroScreen(
                        state = state,
                        onToggleStartPause = viewModel::toggleStartPause,
                        onResetTimer = viewModel::resetTimer,
                        onSelectPhase = viewModel::selectPhase,
                        onToggleOrientation = viewModel::toggleOrientation,
                        onSelectOrientation = viewModel::setOrientation,
                        onSelectBackground = viewModel::selectBackground,
                        onUpdateDurations = viewModel::updateDurations,
                        onNextQuote = viewModel::nextMotivationalQuote,
                        onToggleSound = viewModel::toggleSound,
                        onVolumeChange = viewModel::setSoundVolume,
                        onSelectQuran = viewModel::selectQuranSurahAndReciter,
                        onToggleMasterMute = viewModel::toggleMasterMute,
                        onStopAllSounds = viewModel::stopAllSounds,
                        onDismissSessionBanner = viewModel::dismissSessionBanner
                    )
                }
            }
        }
    }
}
